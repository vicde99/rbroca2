import { useEffect, useState } from 'react'
import { asset } from './asset'

export interface Post { slug: string; title: string; date?: string; author?: string; tag?: string; summary: string; image?: string; body: string }
export interface Blog { updated?: string; posts: Post[] }

export const formatDate = (d?: string) => {
  if (!d) return ''
  const x = new Date(`${d}T00:00:00`)
  return Number.isNaN(x.getTime()) ? d : x.toLocaleDateString('en-PH', { year: 'numeric', month: 'long', day: 'numeric' })
}

export function useBlog() {
  const [blog, setBlog] = useState<Blog | null>(null)
  const [failed, setFailed] = useState(false)
  useEffect(() => {
    let live = true
    fetch(asset('blog.json'), { cache: 'no-cache' })
      .then((r) => (r.ok ? (r.json() as Promise<Blog>) : Promise.reject(new Error('blog'))))
      .then((d) => { if (live) setBlog({ ...d, posts: (d.posts ?? []).filter((p) => /^[a-z0-9]+(-[a-z0-9]+)*$/.test(p.slug) && p.title) }) })
      .catch(() => { if (live) setFailed(true) })
    return () => { live = false }
  }, [])
  return { blog, failed }
}
