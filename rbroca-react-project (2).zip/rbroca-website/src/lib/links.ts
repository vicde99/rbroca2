/** Only https links and in-site links are allowed. Site links written for the HTML site (#contact, #svc-x, #post-x) are mapped to this app's routes. */
export function siteHref(u?: string): string {
  if (!u) return ''
  if (u.startsWith('https://') || u.startsWith('mailto:')) return u
  if (!u.startsWith('#')) return ''
  if (u.startsWith('#/')) return u
  if (u.startsWith('#svc-')) return `#/services/${u.slice(5)}`
  if (u.startsWith('#post-')) return `#/blog/${u.slice(6)}`
  return `#/${u.slice(1)}`
}
