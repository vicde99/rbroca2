import { useEffect, useState } from 'react'
import { asset } from './asset'
import { siteHref } from './links'

export interface Reminder { form: string; what: string; when: string }
export interface NewsItem { id: string; title: string; summary: string; tag?: string; date?: string; link?: string; linkLabel?: string }
export interface News {
  updated?: string
  taxReminder: { title: string; source: string; link: string; linkLabel: string; summary: string; note?: string; reminders: Reminder[] }
  announcements: NewsItem[]
  activities: NewsItem[]
}

/** Only https links and in-site hash links are rendered. */
export const safeLink = (u?: string) => siteHref(u)

export function useNews() {
  const [news, setNews] = useState<News | null>(null)
  const [failed, setFailed] = useState(false)
  useEffect(() => {
    let live = true
    fetch(asset('news.json'), { cache: 'no-cache' })
      .then((r) => (r.ok ? (r.json() as Promise<News>) : Promise.reject(new Error('news'))))
      .then((d) => { if (live) setNews(d) })
      .catch(() => { if (live) setFailed(true) })
    return () => { live = false }
  }, [])
  return { news, failed }
}
