import { asset } from '../lib/asset'
import { ArrowRight } from 'lucide-react'
import { STATS } from '../data'
import { CountUp, Wave } from './ui'

export default function Hero() {
  return (
    <section className="relative isolate overflow-hidden bg-navy-950 text-white">
      <img src={asset('images/hero.jpg')} alt="" fetchPriority="high" className="absolute inset-0 -z-20 h-full w-full object-cover object-right" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/20 max-md:to-navy-950/70" aria-hidden />
      <div className="mx-auto flex min-h-[100svh] max-w-7xl flex-col justify-center px-6 pb-28 pt-32">
        <p className="eyebrow">Business Consultancy</p>
        <h1 className="mt-6 max-w-4xl text-5xl leading-[1.04] tracking-tight sm:text-6xl lg:text-7xl">
          Turning your business vision into <span className="text-gold">steady, measurable growth.</span>
        </h1>
        <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/80">Practical guidance for entrepreneurs and growing companies, from getting started to scaling with confidence, now with IT consulting and digital solutions.</p>
        <div className="mt-10 flex flex-wrap gap-4">
          <a href="#/contact" className="btn btn-gold group">Book a free consultation <ArrowRight size={18} className="transition group-hover:translate-x-1" /></a>
          <a href="#/services" className="btn btn-line">Explore services</a>
        </div>
        <dl className="mt-16 grid max-w-3xl grid-cols-2 gap-8 border-t border-white/20 pt-8 sm:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.label} className="flex flex-col">
              <dt className="order-2 mt-1 text-sm text-white/75">{s.label}</dt>
              <dd className="order-1 font-display text-4xl font-extrabold text-gold"><CountUp to={s.to} prefix={s.prefix} suffix={s.suffix} /></dd>
            </div>
          ))}
        </dl>
      </div>
      <Wave className="absolute inset-x-0 bottom-[-1px] text-paper" />
    </section>
  )
}
