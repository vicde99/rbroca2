import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
// Relative base so the build works on GitHub Pages (project sites) and on any sub-folder.
export default defineConfig({ base: './', plugins: [react()] })
