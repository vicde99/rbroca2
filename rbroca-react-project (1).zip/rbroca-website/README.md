# RBRoca Business Consultancy: React + TypeScript + Tailwind + Lucide

## Run
    npm install
    npm run dev        # local preview
    npm run build      # type-check and production build into dist/

## Structure
- `src/App.tsx`: layout and routes (tiny hash router in `src/lib/router.ts`: `#/services/it-consulting`)
- `src/pages/`: Home, Services, ServiceDetail, Industries, Pricing, About, Careers, Contact, Payment
- `src/components/`: Header (Services dropdown), Hero, Services list, Approach, About, Team, Contact form, Footer, shared form parts, UI primitives (Reveal, CountUp, Wave, PageHero, CtaBand)
- `src/data.ts` and `src/content.ts`: all copy (email, phone, address, services, team, pricing, industries)
- `tailwind.config.js`: brand colors (navy #00296B, yellow #FDC500) and fonts
- `src/index.css`: Futura Extra Bold `@font-face` slot, buttons, cards, form fields

## Notes
- Futura Extra Bold is licensed. It is used when installed; otherwise Jost 800 (Google Fonts) is shown. To self-host, add your .woff2 and an `@font-face` in `src/index.css`.
- Forms post to FormSubmit for info@rbrocaconsultancy.com. The first submission sends a one-time activation email to that address.
- The GCash and QR Ph codes on the Payment page show a "not available yet" note until you add the images: put them in `public/images/` and set the paths in `src/pages/Payment.tsx` (`QR`).
- Not yet ported from the HTML site: Resources (calculators, templates, agencies), Blog, FAQ and the legal pages (Privacy, Terms, Cookies, Accessibility).
