import { useEffect, useState } from 'react'

const read = () => '/' + window.location.hash.replace(/^#\/?/, '').replace(/\/$/, '')

/** Tiny hash router: "#/services/it-consulting" -> "/services/it-consulting". */
export function useRoute() {
  const [path, setPath] = useState(read)
  useEffect(() => {
    const onChange = () => { setPath(read()); window.scrollTo({ top: 0 }) }
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])
  return path
}
