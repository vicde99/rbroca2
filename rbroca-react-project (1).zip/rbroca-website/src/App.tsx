import { useEffect, useRef } from 'react'
import { SERVICES } from './data'
import CookieNotice from './components/CookieNotice'
import Footer from './components/Footer'
import Header from './components/Header'
import WhatsAppButton from './components/WhatsAppButton'
import { useRoute } from './lib/router'
import AboutPage from './pages/AboutPage'
import Careers from './pages/Careers'
import ContactPage from './pages/ContactPage'
import Home from './pages/Home'
import Industries from './pages/Industries'
import NotFound from './pages/NotFound'
import Payment from './pages/Payment'
import Pricing from './pages/Pricing'
import ServiceDetail from './pages/ServiceDetail'
import ServicesPage from './pages/ServicesPage'

const TITLES: Record<string, string> = { '/': 'Accounting, Tax and Business Support', '/services': 'Services', '/industries': 'Industries', '/pricing': 'Pricing', '/about': 'About', '/careers': 'Careers', '/contact': 'Contact', '/payment': 'Payment' }

function Page({ path }: { path: string }) {
  if (path === '/' || path === '') return <Home />
  if (path === '/services') return <ServicesPage />
  if (path.startsWith('/services/')) return <ServiceDetail id={path.slice('/services/'.length)} />
  if (path === '/industries') return <Industries />
  if (path === '/pricing') return <Pricing />
  if (path === '/about') return <AboutPage />
  if (path === '/careers') return <Careers />
  if (path === '/contact') return <ContactPage />
  if (path === '/payment') return <Payment />
  return <NotFound />
}

export default function App() {
  const path = useRoute()
  const main = useRef<HTMLElement>(null)
  const first = useRef(true)
  useEffect(() => {
    const svc = SERVICES.find((s) => path === `/services/${s.id}`)
    const t = svc ? svc.title : TITLES[path === '' ? '/' : path] ?? 'Page not found'
    document.title = `${t} | RBRoca Business Consultancy`
    if (first.current) { first.current = false; return }
    main.current?.focus({ preventScroll: true })
  }, [path])
  return (
    <>
      <a href="#main" onClick={(e) => { e.preventDefault(); main.current?.focus() }} className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2">Skip to content</a>
      <Header path={path === '' ? '/' : path} />
      <main id="main" ref={main} tabIndex={-1} className="outline-none"><Page path={path} /></main>
      <Footer />
      <WhatsAppButton />
      <CookieNotice />
    </>
  )
}
