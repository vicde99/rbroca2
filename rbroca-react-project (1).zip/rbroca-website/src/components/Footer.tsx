import { NAV, SERVICES, SITE } from '../data'
import { SocialLinks } from './Social'

export default function Footer() {
  const h = 'font-display text-sm font-extrabold uppercase tracking-wider text-gold'
  return (
    <footer className="texture bg-navy-950 pb-10 pt-4 text-white/75">
      <div className="mx-auto max-w-7xl border-t border-white/15 px-6 pt-14">
        <div className="grid gap-12 md:grid-cols-[1.3fr_1fr_1fr]">
          <div>
            <a href="#/" className="flex items-center gap-3 text-white" aria-label="RBRoca home">
              <img src="/images/logo-mark.png" alt="" className="h-14 w-auto" width={56} height={56} />
              <span className="leading-none"><span className="block font-display text-xl font-extrabold">RBRoca</span><span className="block text-[10px] tracking-[.28em] text-gold">BUSINESS CONSULTANCY</span></span>
            </a>
            <p className="mt-6 max-w-sm leading-relaxed">Practical guidance for entrepreneurs and growing companies. Turning your business vision into steady, measurable growth.</p>
            <div className="mt-6"><SocialLinks /></div>
            <address className="mt-6 text-sm not-italic leading-relaxed">{SITE.address}<br />{SITE.phone}<br /><a className="hover:text-gold" href={`mailto:${SITE.email}`}>{SITE.email}</a></address>
          </div>
          <div><h2 className={h}>Services</h2><ul className="mt-5 space-y-3">{SERVICES.map((s) => <li key={s.id}><a className="hover:text-gold" href={`#/services/${s.id}`}>{s.title}</a></li>)}</ul></div>
          <div><h2 className={h}>Company</h2><ul className="mt-5 space-y-3">{NAV.map((n) => <li key={n.href}><a className="hover:text-gold" href={n.href}>{n.label}</a></li>)}<li><a className="hover:text-gold" href="#/payment">Payment</a></li></ul></div>
        </div>
        <p className="mt-14 border-t border-white/15 pt-6 text-sm">© {new Date().getFullYear()} RBRoca Business Consultancy. All rights reserved.</p>
      </div>
    </footer>
  )
}
