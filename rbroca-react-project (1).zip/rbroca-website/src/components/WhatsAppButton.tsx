import { SITE } from '../data'
import { BrandIcon } from './Social'

export default function WhatsAppButton() {
  return (
    <a href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent("Hi RBRoca, I'd like to ask about your services.")}`} target="_blank" rel="noopener noreferrer"
      aria-label="Chat with RBRoca on WhatsApp" className="fixed bottom-5 right-5 z-30 grid h-14 w-14 place-items-center rounded-full bg-[#25d366] text-white shadow-xl transition hover:scale-110">
      <BrandIcon name="whatsapp" size={30} />
    </a>
  )
}
