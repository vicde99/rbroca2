import { useEffect, useRef, useState } from 'react'
import { ChevronDown, Menu, X } from 'lucide-react'
import { NAV, SERVICES } from '../data'

export default function Header({ path }: { path: string }) {
  const [open, setOpen] = useState(false)
  const [dd, setDd] = useState(false)
  const [solid, setSolid] = useState(false)
  const ddRef = useRef<HTMLDivElement>(null)
  const lightTop = path !== '/'

  useEffect(() => {
    const on = () => setSolid(window.scrollY > 24)
    on(); window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  useEffect(() => { setOpen(false); setDd(false) }, [path])
  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpen(false); setDd(false) } }
    const out = (e: MouseEvent) => { if (ddRef.current && !ddRef.current.contains(e.target as Node)) setDd(false) }
    window.addEventListener('keydown', esc); document.addEventListener('mousedown', out)
    return () => { window.removeEventListener('keydown', esc); document.removeEventListener('mousedown', out) }
  }, [])

  const active = (href: string) => (path === href.slice(1) || (href !== '#/' && path.startsWith(href.slice(1) + '/')))
  const link = 'relative rounded-full px-4 py-2 font-display text-[14px] font-extrabold tracking-wide text-white/85 transition hover:text-gold'

  return (
    <header className={`fixed inset-x-0 top-0 z-40 transition duration-300 ${solid || open || lightTop ? 'bg-navy-950/95 shadow-[0_10px_30px_-12px_rgba(0,0,0,.5)] backdrop-blur' : 'bg-transparent'}`}>
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <a href="#/" className="flex items-center gap-3 text-white" aria-label="RBRoca Business Consultancy, home">
          <img src="/images/logo-mark.png" alt="" className="h-11 w-auto" width={44} height={44} />
          <span className="leading-none">
            <span className="block font-display text-lg font-extrabold tracking-wide">RBRoca</span>
            <span className="block text-[10px] font-medium tracking-[.28em] text-gold">BUSINESS CONSULTANCY</span>
          </span>
        </a>

        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          <div ref={ddRef} className="relative" onMouseEnter={() => setDd(true)} onMouseLeave={() => setDd(false)}>
            <button type="button" aria-expanded={dd} aria-controls="services-menu" onClick={() => setDd((v) => !v)} className={`${link} inline-flex items-center gap-1 ${path.startsWith('/services') ? 'text-gold' : ''}`}>
              Services <ChevronDown size={16} className={`transition ${dd ? 'rotate-180' : ''}`} aria-hidden />
            </button>
            {dd && (
              <div id="services-menu" className="absolute left-0 top-full w-[22rem] pt-3">
                <ul className="rounded-2xl border border-white/10 bg-navy-950 p-2 shadow-2xl">
                  {SERVICES.map((s) => (
                    <li key={s.id}>
                      <a href={`#/services/${s.id}`} className="flex items-center justify-between rounded-xl px-4 py-3 text-[15px] text-white/90 transition hover:bg-white/10 hover:text-gold">
                        <span>{s.title}</span>{s.isNew && <span className="rounded-full bg-gold px-2 py-0.5 text-[10px] font-extrabold text-navy">NEW</span>}
                      </a>
                    </li>
                  ))}
                  <li className="mt-1 border-t border-white/10 pt-1"><a href="#/services" className="block rounded-xl px-4 py-3 text-[15px] font-bold text-gold hover:bg-white/10">View all services</a></li>
                </ul>
              </div>
            )}
          </div>
          {NAV.map((n) => (
            <a key={n.href} href={n.href} aria-current={active(n.href) ? 'page' : undefined} className={`${link} ${active(n.href) ? 'text-gold' : ''}`}>{n.label}</a>
          ))}
          <a href="#/contact" className="btn btn-gold ml-4 !py-2.5">Book a consultation</a>
        </nav>

        <button type="button" className="grid h-11 w-11 place-items-center rounded-full text-white lg:hidden" aria-expanded={open} aria-controls="mobile-nav" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen((v) => !v)}>
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="max-h-[80svh] overflow-y-auto border-t border-white/10 px-6 pb-6 pt-2 lg:hidden">
          <a href="#/services" className="block border-b border-white/10 py-4 font-display text-lg font-extrabold text-white">Services</a>
          {SERVICES.map((s) => <a key={s.id} href={`#/services/${s.id}`} className="block border-b border-white/5 py-3 pl-4 text-[15px] text-white/75">{s.title}</a>)}
          {NAV.map((n) => <a key={n.href} href={n.href} className="block border-b border-white/10 py-4 font-display text-lg font-extrabold text-white">{n.label}</a>)}
          <a href="#/contact" className="btn btn-gold mt-5 w-full">Book a consultation</a>
        </nav>
      )}
    </header>
  )
}
