import { PageHero } from '../components/ui'

export default function NotFound() {
  return (
    <>
      <PageHero eyebrow="404" title="We could not find that page.">The link may be old. Head back home or see our services.</PageHero>
      <section className="bg-paper pb-24"><div className="mx-auto flex max-w-7xl gap-4 px-6"><a href="#/" className="btn btn-navy">Back to home</a><a href="#/services" className="btn btn-navy">View services</a></div></section>
    </>
  )
}
