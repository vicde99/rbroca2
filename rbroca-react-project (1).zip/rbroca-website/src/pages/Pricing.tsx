import { Check, X } from 'lucide-react'
import { ADDONS, PRICING_FAQ, TIERS } from '../data'
import { CtaBand, PageHero, Reveal } from '../components/ui'

export default function Pricing() {
  return (
    <>
      <PageHero eyebrow="Pricing" title="Fixed-fee retainers, no surprises.">Choose a tier or ask us about a custom engagement. We keep pricing transparent because we are confident in the value.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto grid max-w-7xl items-stretch gap-6 px-6 lg:grid-cols-3">
          {TIERS.map((t, i) => (
            <Reveal key={t.name} delay={i * 90} className="h-full">
              <article className={`card-line flex h-full flex-col p-8 ${t.popular ? '!border-2 !border-gold' : ''}`}>
                {t.popular && <span className="mb-3 w-fit rounded-full bg-gold px-3 py-1 text-xs font-extrabold text-navy">Most popular</span>}
                <h2 className="text-3xl text-navy">{t.name}</h2><p className="mt-1 text-sm text-ink/60">{t.sub}</p>
                <p className="mt-5 font-display text-3xl font-extrabold text-navy-700">Custom quote</p><p className="text-sm text-ink/60">Fixed monthly fee, scoped to your business.</p>
                <p className="mt-5 text-[15px] leading-relaxed"><b>Best for:</b> {t.best}</p>
                <ul className="mt-5 flex-1 space-y-2.5 text-[15px]">{t.items.map((it) => <li key={it} className="flex gap-3"><Check size={18} className="mt-0.5 flex-none text-navy-700" aria-hidden />{it}</li>)}
                  {t.no?.map((n) => <li key={n} className="flex gap-3 text-ink/50"><X size={18} className="mt-0.5 flex-none" aria-hidden />{n}</li>)}</ul>
                <a href="#/contact" className={`btn mt-8 ${t.popular ? 'btn-gold' : 'btn-navy'}`}>{t.cta}</a>
              </article>
            </Reveal>
          ))}
        </div>
        <p className="mx-auto mt-10 max-w-3xl px-6 text-center text-ink/65">Every engagement is scoped to your business. Your final quote reflects transaction volume, headcount, registration setup and any cleanup needed. Each proposal is one fixed monthly fee, with no hidden costs and no per-call billing.</p>
      </section>
      <section className="bg-white py-24"><div className="mx-auto max-w-4xl px-6">
        <p className="eyebrow !text-navy-700">Add-ons</p><h2 className="mt-3 text-4xl text-navy">One-time and specialized work</h2>
        <ul className="mt-8 divide-y divide-navy/10 border-y border-navy/10">{ADDONS.map((a) => <li key={a} className="flex justify-between gap-6 py-4"><span>{a}</span><span className="flex-none font-bold text-navy-700">Quoted per scope</span></li>)}</ul>
      </div></section>
      <section className="bg-paper py-24"><div className="mx-auto max-w-3xl px-6">
        <p className="eyebrow !text-navy-700">FAQ</p><h2 className="mt-3 text-4xl text-navy">Pricing questions</h2>
        <div className="mt-8 space-y-3">{PRICING_FAQ.map(([q, a]) => <details key={q} className="group rounded-2xl border border-navy/10 bg-white p-5 open:shadow-md"><summary className="cursor-pointer font-display font-extrabold text-navy">{q}</summary><p className="mt-3 text-ink/70">{a}</p></details>)}</div>
      </div></section>
      <CtaBand />
    </>
  )
}
