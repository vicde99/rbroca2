import { useState } from 'react'
import { Send } from 'lucide-react'
import { useFormSubmit } from '../lib/useForm'
import { Field, Honeypot, StatusDialog } from '../components/Form'
import { PageHero } from '../components/ui'

type Method = 'GCash' | 'Maya' | 'QR Ph'
const QR: Record<Method, string> = { GCash: '', Maya: '/images/maya-qr.jpg', 'QR Ph': '' }

export default function Payment() {
  const [method, setMethod] = useState<Method>('GCash')
  const { sending, status, close, onSubmit } = useFormSubmit('Payment', { method: 'Payment method', name: 'Name', phone: 'Phone', email: 'Email', amount: 'Amount (PHP)', reference: 'Reference #' })
  return (
    <>
      <PageHero eyebrow="Payment" title="Pay RBRoca.">Pay with GCash, Maya or any QR Ph-enabled bank or e-wallet, then submit your details so we can match your payment.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 lg:grid-cols-[minmax(0,380px)_1fr]">
          <div className="card-line self-start p-6 text-center lg:sticky lg:top-28">
            <h2 className="text-xl text-navy">Scan to pay with {method}</h2>
            {QR[method] ? <img src={QR[method]} alt={`${method} QR code for RBRoca`} className="mx-auto mt-5 w-full max-w-xs rounded-2xl border border-navy/10 bg-white p-2" /> : <p className="mt-5 grid min-h-64 place-items-center rounded-2xl border-2 border-dashed border-navy/20 p-6 text-ink/60">The {method} QR code is not available yet. Please pay with another method or contact us.</p>}
            <p className="mt-4 text-sm text-ink/60">Open your app, scan the code, enter the amount, and keep your receipt or reference number.</p>
          </div>
          <form onSubmit={(e) => void onSubmit(e)} className="relative rounded-3xl bg-white p-8 shadow-xl md:p-10" aria-label="Payment details form">
            <Honeypot />
            <fieldset><legend className="mb-2 text-sm font-extrabold text-navy">Payment method *</legend>
              <div className="flex flex-wrap gap-3">{(['GCash', 'Maya', 'QR Ph'] as Method[]).map((m) => (
                <label key={m} className={`flex cursor-pointer items-center gap-2 rounded-full border-2 px-5 py-2.5 font-bold transition ${method === m ? 'border-gold bg-gold/20' : 'border-navy/15'}`}>
                  <input type="radio" name="method" value={m} checked={method === m} onChange={() => setMethod(m)} className="accent-[#00296B]" />{m}</label>))}</div></fieldset>
            <div className="mt-6 grid gap-5">
              <Field id="p-name" label="Full name *"><input id="p-name" name="name" required autoComplete="name" className="field" /></Field>
              <Field id="p-phone" label="Phone number *"><input id="p-phone" name="phone" type="tel" required autoComplete="tel" className="field" /></Field>
              <Field id="p-email" label="Email *"><input id="p-email" name="email" type="email" required autoComplete="email" className="field" /></Field>
              <Field id="p-amount" label="Amount (PHP) *"><input id="p-amount" name="amount" type="number" min="1" step="0.01" required inputMode="decimal" placeholder="e.g. 1500.00" className="field" /></Field>
              <Field id="p-ref" label="Reference # *" hint="Invoice number or the reference number on your receipt."><input id="p-ref" name="reference" required className="field" /></Field>
            </div>
            <p className="mt-4 text-sm text-ink/60"><b>Please do not</b> send PINs, OTPs, passwords or card details.</p>
            <button type="submit" disabled={sending} className="btn btn-navy mt-6 w-full disabled:opacity-60">{sending ? 'Sending…' : <>Submit payment details <Send size={18} aria-hidden /></>}</button>
          </form>
        </div>
        <StatusDialog status={status} onClose={close} />
      </section>
    </>
  )
}
