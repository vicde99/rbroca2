import { Check, Send } from 'lucide-react'
import { SERVICES } from '../data'
import { useFormSubmit } from '../lib/useForm'
import { Field, Honeypot, StatusDialog } from '../components/Form'
import { CtaBand, PageHero, Reveal, SectionTitle } from '../components/ui'
import NotFound from './NotFound'

export default function ServiceDetail({ id }: { id: string }) {
  const s = SERVICES.find((x) => x.id === id)
  const { sending, status, close, onSubmit } = useFormSubmit('Service inquiry', { name: 'Name', business: 'Business', email: 'Email', phone: 'Phone', service: 'Service', message: 'Message' })
  if (!s) return <NotFound />
  return (
    <>
      <PageHero eyebrow={s.isNew ? 'New service' : 'Service'} title={s.title}>
        <p>{s.lead}</p>
        <div className="mt-8 flex flex-wrap gap-4"><a href="#/contact" className="btn btn-gold">Discuss this service</a><a href="#/services" className="btn btn-line">All services</a></div>
      </PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto max-w-7xl px-6">
          <ol className="grid gap-x-12 gap-y-2 md:grid-cols-2">
            {s.pillars.map((p, i) => (
              <li key={p.title}><Reveal delay={i * 70}><div className="border-t border-navy/15 py-8"><span className="font-display text-sm font-extrabold text-navy-700/60">{String(i + 1).padStart(2, '0')}</span><h2 className="mt-2 text-2xl text-navy">{p.title}</h2><p className="mt-3 leading-relaxed text-ink/70">{p.text}</p></div></Reveal></li>
            ))}
          </ol>
        </div>
      </section>
      {s.steps && (
        <section className="texture bg-navy-950 py-24 text-white">
          <div className="mx-auto max-w-7xl px-6"><SectionTitle light eyebrow="How it runs" title="A clear path from idea to handover." />
            <ol className="mt-14 grid gap-10 md:grid-cols-4">{s.steps.map((st, i) => <li key={st.title} className="border-t-2 border-gold pt-6"><span className="font-display text-sm font-extrabold text-gold">0{i + 1}</span><h3 className="mt-3 text-2xl">{st.title}</h3><p className="mt-3 text-white/70">{st.text}</p></li>)}</ol>
            {s.who && <p className="mt-14 max-w-3xl text-lg text-white/80"><b className="text-gold">Who this is for: </b>{s.who}</p>}
          </div>
        </section>
      )}
      <section className="bg-white py-24">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 lg:grid-cols-2">
          <div><SectionTitle eyebrow="What’s included" title="Everything you need, clearly scoped." />
            <ul className="mt-10 space-y-4">{s.included.map((i) => <li key={i} className="flex items-start gap-3 text-lg text-ink/80"><span className="mt-1 grid h-6 w-6 flex-none place-items-center rounded-full bg-gold text-navy"><Check size={14} strokeWidth={3} aria-hidden /></span>{i}</li>)}</ul></div>
          <form onSubmit={(e) => void onSubmit(e)} className="relative rounded-3xl border border-navy/10 bg-paper p-8" aria-label={`Quick inquiry about ${s.title}`}>
            <Honeypot /><input type="hidden" name="service" value={s.title} />
            <h2 className="text-2xl text-navy">Quick inquiry</h2><p className="mt-2 text-ink/65">Tell us about your business and we will reply within one business day.</p>
            <div className="mt-6 grid gap-5">
              <Field id="q-name" label="Your name *"><input id="q-name" name="name" required autoComplete="name" className="field" /></Field>
              <Field id="q-biz" label="Business name"><input id="q-biz" name="business" autoComplete="organization" className="field" /></Field>
              <Field id="q-email" label="Email *"><input id="q-email" name="email" type="email" required autoComplete="email" className="field" /></Field>
              <Field id="q-phone" label="Phone *"><input id="q-phone" name="phone" type="tel" required autoComplete="tel" className="field" /></Field>
              <Field id="q-msg" label="How can we help? *"><textarea id="q-msg" name="message" rows={3} required className="field" /></Field>
            </div>
            <p className="mt-4 text-sm text-ink/60"><b>Please do not</b> include TINs, account numbers or other sensitive details.</p>
            <button type="submit" disabled={sending} className="btn btn-navy mt-6 w-full disabled:opacity-60">{sending ? 'Sending…' : <>Send inquiry <Send size={18} /></>}</button>
          </form>
        </div>
        <StatusDialog status={status} onClose={close} />
      </section>
      <CtaBand />
    </>
  )
}
