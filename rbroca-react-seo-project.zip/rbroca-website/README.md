# RBRoca Business Consultancy: React + TypeScript + Tailwind + Lucide

## Run
    npm install
    npm run dev        # local preview
    npm run build      # type-check and production build into dist/

## Structure
- `src/App.tsx`: layout and routes (tiny hash router in `src/lib/router.ts`: `#/services/it-consulting`)
- `src/pages/`: Home, Services, ServiceDetail, Industries, Pricing, About, Careers, Contact, Payment
- `src/components/`: Header (Services dropdown), Hero, Services list, Approach, About, Team, Contact form, Footer, shared form parts, UI primitives (Reveal, CountUp, Wave, PageHero, CtaBand)
- `src/data.ts` and `src/content.ts`: all copy (email, phone, address, services, team, pricing, industries)
- `tailwind.config.js`: brand colors (navy #00296B, yellow #FDC500) and fonts
- `src/index.css`: Futura Extra Bold `@font-face` slot, buttons, cards, form fields

## Notes
- Futura Extra Bold is licensed. It is used when installed; otherwise Jost 800 (Google Fonts) is shown. To self-host, add your .woff2 and an `@font-face` in `src/index.css`.
- Forms post to FormSubmit for info@rbrocaconsultancy.com. The first submission sends a one-time activation email to that address.
- The GCash and QR Ph codes on the Payment page show a "not available yet" note until you add the images: put them in `public/images/` and set the paths in `src/pages/Payment.tsx` (`QR`).
- Not yet ported from the HTML site: Resources (calculators, templates, agencies), FAQ and the legal pages (Privacy, Terms, Cookies, Accessibility).

## Blog, News and the Content Manager
The Blog (`#/blog`) reads `public/blog.json` and the News page reads `public/news.json`. The Content Manager is at `/admin/` on the published site (source: `public/admin/index.html`).
The News tab (`#/news`) reads `public/news.json` at runtime. Edit that file to change the BIR Tax Reminder card, company announcements and company activities. Only `https://` and in-site `#/...` links are shown. No rebuild is needed when you edit `news.json` directly on the published site.

## Deploy on GitHub Pages
1. Push this folder to a GitHub repository (branch `main`).
2. In the repository: Settings > Pages > Source: **GitHub Actions**.
3. The workflow in `.github/workflows/deploy.yml` builds and publishes the site on every push. The site address is shown in the workflow run.
The build uses relative paths (`base: './'`) and a hash router, so it works from a project site such as `https://<user>.github.io/<repo>/`.

CONTENT MANAGER (CMS)
=====================
Open  https://<your-site>/admin/  (add /admin/ to your site address).
It edits two files in your GitHub repository: public/news.json and public/blog.json.

First-time setup (about 3 minutes)
  1. On GitHub: Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token.
  2. Repository access: "Only select repositories" > choose this website's repository.
  3. Permissions > Repository permissions > Contents: Read and write. Generate and copy the token.
  4. Open /admin/, enter  owner/repository  (for example rbroca/rbroca-website), the branch (main),
     paste the token, and press "Connect and load content".

Everyday use
  - Announcements, Company activities: add, edit, reorder (arrows) or delete items. They show on the News page in this order.
  - Tax reminder: edit the BIR card text, link and the Common deadlines table.
  - Blog posts: New post, then fill in title, summary and article text (preview shown). The web address is created from the title.
    Article text: blank line between paragraphs, ## Heading, ### Subheading, - bullets, 1. numbered list, **bold**, [text](https://link).
  - Press "Save to GitHub". The site updates in about a minute. Nothing changes on the site until you press Save.

Good to know
  - The token stays in your browser and is sent only to GitHub. Leave "Remember" unchecked on shared computers.
  - Only people with write access to the repository (and a token) can publish changes. The admin page itself shows nothing without a token.
  - Offline option: "Open JSON files from my computer", edit, then "Download", and upload the files to your site yourself.
  - Links must start with https:// (or # for pages on this site). Cover images must be https:// addresses.

## Favicon
The RBRoca mark on a navy tile: `public/favicon.ico`, `public/images/favicon-32.png`, `public/images/apple-touch-icon.png` (also 192 and 512 px versions). Replace those files to change it.

## SEO and GEO build
- `npm run build` makes the site, a server bundle, then `scripts/prerender.mjs` writes one HTML file per page (48 pages), plus sitemap.xml, robots.txt, llms.txt and 404.html.
- SEO settings are in `public/seo.json`: site address (`siteUrl`, or the SITE_URL variable), business details used in structured data (address, phone, coordinates: please set your exact latitude and longitude), per-page title and description overrides (`pages`), and per-location notes or switches (`locations`).
- Locations are defined in `src/locations.ts`. Add a short local note for each place in `public/seo.json` > `locations` to make the pages more useful.
- GitHub Pages: the workflow in `.github/workflows/deploy.yml` sets the base path and site address automatically. For a custom domain, add `public/CNAME` containing the domain.
- After publishing: verify the site in Google Search Console and Bing Webmaster Tools, and submit sitemap.xml.
