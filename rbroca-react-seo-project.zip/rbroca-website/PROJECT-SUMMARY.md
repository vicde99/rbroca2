RBRoca Business Consultancy: project summary (as of Friday, November 20, 2026)
==========================================================================

WHAT IS FINISHED AND WORKING
- Main website (rbroca-business-consultancy.html, one file): Home, Services (6 practices + a page for each), Industries (20), Pricing,
  Resources (calculators, readiness check, registration wizard, tax calendar, permit checklist, 8 downloadable CSV templates, agencies list),
  News (BIR Tax Reminder link, announcements, company activities), Blog (articles open on their own page), About (Who we are, Mission and Vision,
  team, Registrations), Careers (application form with resume), Contact (inquiry and callback forms), Payment (GCash / Maya / QR Ph, Maya QR added),
  FAQ and four legal pages (Privacy under RA 10173, Terms, Cookies, Accessibility).
- Brand: navy #00296B and yellow #FDC500, Futura Extra Bold headings (Jost fallback), RBRoca logo and favicon.
- Contact details: 1422 Tramo-Bantayan, Kawit, Cavite; +63 9617722601; info@rbrocaconsultancy.com. Social icons: Facebook, Instagram, TikTok.
- Chat button: Facebook Messenger (m.me/61580893335282). WhatsApp stays as a contact link.
- Forms (inquiry, callback, careers with resume, payment, service quick inquiry) send to info@rbrocaconsultancy.com through FormSubmit and show a "sent" popup.
- Content Manager (admin/index.html): edit News, Announcements, Company activities, Tax reminder and Blog posts; saves to GitHub (news.json, blog.json).
- Accessibility and UX pass: labelled form fields, keyboard tabs and menu, page titles, focus handling, reduced-motion, no horizontal scrolling from 360 to 1920 px.
- Basic SEO on the main file: meta tags, Open Graph, geo meta, structured data (LocalBusiness with every location), Content-Security-Policy.

SEO + GEO BUILD (React project, rbroca-react-seo-project.zip)
- Every page is pre-rendered as its own crawlable URL (48 pages): services, industries, pricing, news, about, careers, contact, blog articles,
  a Service areas page, 4 region pages (Cavite, Metro Manila, Bulacan, Rizal) and 24 area pages (Kawit, Imus, General Trias, Bacoor, Rosario,
  Tanza, Magallanes, Trece Martires, Naic, Intramuros, Tondo, Santa Ana, Santa Cruz, Sampaloc, Parañaque, Pasig, Las Piñas, Mandaluyong,
  Pasay, Makati, Quezon City, Antipolo, Taytay, Cainta).
- Each page has its own title, description, canonical URL, Open Graph and geo tags, and structured data (LocalBusiness, Service, FAQ, Breadcrumb, BlogPosting).
- Generated at build time: sitemap.xml, robots.txt, llms.txt (summary for AI assistants), 404.html.
- GitHub Actions workflow builds and publishes on every push (also when the Content Manager saves news or blog changes).

NOT FINISHED YET
- Content Manager menus for SEO and GEO (SEO settings, Locations, SEO and GEO monitor, keyword log, tools and checklist).
  Today SEO settings live in public/seo.json (site address, business details, per-page title and description, per-location notes).
- Real SEO structure on the single-file site: its pages use # links, so search engines see one page. Use the React SEO build for full SEO.
- React version still lacks: Resources, FAQ and the legal pages.
- GCash and QR Ph QR codes (images not received). Your hero photo with the TAX letters removed is in use.
- Not tested here: the real Vite build (tested with an equivalent esbuild build), real GitHub saves and emails (tested with simulated services).

QA AND SECURITY CHECKS RUN AT THE END OF THIS SESSION
- Main site: 68 functional checks (pages, links, forms, calculators, news, blog, accessibility, 6 screen widths, CSP, admin page).
- React SEO build: 419 static checks (titles, descriptions, canonicals, JSON-LD, links, sitemap, all 24 locations) and 25 browser checks.
- Vulnerability scan: no hard-coded secrets, no eval or document.write, no unsafe links, all external links use noopener, CSP present,
  the form handler strips header injection, validates email and file type and never saves uploads. Run "npm audit" after "npm install" for dependencies.
