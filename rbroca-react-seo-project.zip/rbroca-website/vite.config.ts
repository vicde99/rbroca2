import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
// VITE_BASE is '/' for a custom domain or user site, and '/<repo>/' for a GitHub project site (the workflow sets it).
export default defineConfig({ base: process.env.VITE_BASE ?? '/', plugins: [react()] })
