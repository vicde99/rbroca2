/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: { navy: { DEFAULT: '#00296B', 950: '#001B46', 700: '#0A3A8C' }, gold: { DEFAULT: '#FDC500', soft: '#FFE27A' }, paper: '#f4f6fb', ink: '#0c1a33' },
      fontFamily: {
        sans: ['"Futura PT"', 'Futura', 'Jost', '"Century Gothic"', 'system-ui', 'sans-serif'],
        display: ['"Futura Extra Bold"', 'Futura-ExtraBold', '"Futura PT"', 'Futura', 'Jost', '"Century Gothic"', 'system-ui', 'sans-serif'],
      },
      letterSpacing: { wider2: '.22em' },
    },
  },
  plugins: [],
}
