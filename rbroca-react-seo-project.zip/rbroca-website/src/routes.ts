import type { AppData } from './lib/appdata'
import { SERVICES } from './data'
import { AREAS, REGIONS, locationPath, regionPath } from './locations'
import { isAreaEnabled } from './seo'

/** Every page that gets its own static HTML file. */
export function routes(data: AppData): string[] {
  const seo = data.seo ?? {}
  return [
    '/', '/services', ...SERVICES.map((s) => `/services/${s.id}`),
    '/industries', '/pricing', '/news', '/about', '/careers', '/contact', '/payment', '/blog',
    ...data.blog.posts.filter((p) => /^[a-z0-9]+(-[a-z0-9]+)*$/.test(p.slug)).map((p) => `/blog/${p.slug}`),
    '/locations', ...REGIONS.map(regionPath), ...AREAS.filter((a) => isAreaEnabled(seo, a.slug)).map(locationPath),
  ]
}
