/* Generated from the approved site copy. Edit freely. */
export interface Pillar { title: string; text: string }
export interface ServiceFull { id: string; title: string; summary: string; points: string[]; isNew?: boolean; lead: string; pillars: Pillar[]; included: string[]; steps?: Pillar[]; who?: string }
export const SERVICES: ServiceFull[] = [
  {
    "id": "bookkeeping-tax",
    "title": "Bookkeeping & Tax Accounting",
    "summary": "Organized books. Filings that are never late.",
    "points": [
      "Day-to-day recording with reconciled accounts",
      "Monthly, quarterly and yearly BIR returns",
      "VAT, percentage tax, withholding and income tax",
      "Financial statements and management reports"
    ],
    "lead": "Reliable records and punctual BIR filings, so every decision you make rests on numbers you can trust.",
    "pillars": [
      {
        "title": "Day-to-day bookkeeping",
        "text": "We post your sales, expenses and bank activity in spreadsheets or cloud software such as QuickBooks or Xero, reconcile your accounts, and close each month with a checked trial balance."
      },
      {
        "title": "Tax compliance",
        "text": "We prepare and file your VAT, percentage tax, withholding and income tax returns on schedule, together with the supporting alphalists, and remind you well before anything falls due."
      },
      {
        "title": "Reports you can use",
        "text": "Expect a monthly profit and loss and balance sheet, yearly financial statements, and simple management reports on budgets, margins and cash flow."
      },
      {
        "title": "Ready for any review",
        "text": "Because ledgers and documents stay current all year, a BIR notice or an auditor’s visit becomes a routine task instead of an emergency."
      }
    ],
    "included": [
      "Bookkeeping and monthly closing",
      "Bank and account reconciliations",
      "BIR returns from monthly to annual",
      "Alphalists and inventory reports",
      "Financial statements and management reports"
    ]
  },
  {
    "id": "hr-payroll",
    "title": "HR & Payroll Outsourcing",
    "summary": "Payroll on time. HR on the right side of the law.",
    "points": [
      "Payroll setup, registers and time records",
      "SSS, PhilHealth and Pag-IBIG computation and remittance",
      "Withholding tax and year-end annualization",
      "13th month pay and labor reports"
    ],
    "lead": "A dependable payroll and HR back office, so your people are paid correctly and your records satisfy the agencies.",
    "pillars": [
      {
        "title": "Payroll processing",
        "text": "We set up your payroll structure, prepare registers from your time records, and produce payslips for every cut-off."
      },
      {
        "title": "Government contributions",
        "text": "We compute the employee and employer shares for SSS, PhilHealth and Pag-IBIG and prepare the remittance schedules."
      },
      {
        "title": "Tax and year-end",
        "text": "Monthly withholding on compensation, year-end annualization, employee tax certificates (BIR Form 2316) and 13th month pay are handled for you."
      },
      {
        "title": "HR records and compliance",
        "text": "We help organize employment contracts and employee files and prepare the regular reports that labor authorities require."
      }
    ],
    "included": [
      "Payroll structure, registers and daily time records",
      "SSS, PhilHealth and Pag-IBIG computation and remittance schedules",
      "Withholding on compensation and BIR Form 2316",
      "13th month pay computation",
      "Employee files and labor reporting support"
    ]
  },
  {
    "id": "business-documentation",
    "title": "Business Documentation",
    "summary": "Registrations and permits, taken care of.",
    "points": [
      "DTI and SEC registration, including amendments",
      "New and renewed business permits",
      "SSS, PhilHealth, Pag-IBIG and DOLE registrations",
      "Help with CDA, PCAB and FDA licenses"
    ],
    "lead": "From your first registration to every yearly renewal, we keep your business properly papered and legally in order.",
    "pillars": [
      {
        "title": "Start-up registration",
        "text": "We guide you through naming, DTI or SEC registration and later amendments, then continue to BIR and local government registration."
      },
      {
        "title": "Permits and renewals",
        "text": "We prepare the requirements for new Mayor’s permits and handle renewals on time so your operations never lapse."
      },
      {
        "title": "Employer registrations",
        "text": "When you hire, we register you with SSS, PhilHealth, Pag-IBIG and DOLE and set up the records each agency expects."
      },
      {
        "title": "Sector licenses",
        "text": "Cooperatives, contractors and food or health product businesses often need extra approvals. We assist with CDA, PCAB and FDA applications."
      }
    ],
    "included": [
      "DTI and SEC registration and amendments",
      "New and renewed business permits",
      "SSS, PhilHealth, Pag-IBIG and DOLE registration",
      "CDA, PCAB and FDA license assistance",
      "Renewal reminders and document tracking"
    ]
  },
  {
    "id": "business-support",
    "title": "Other Business Support",
    "summary": "Hands-on help for the everyday.",
    "points": [
      "Business consultation and financial analysis",
      "Follow-up on receivables and payables",
      "Liaison work, PSA requests and SSS or HDMF enrollments",
      "Help with title transfers, deeds and notarization"
    ],
    "lead": "Practical, flexible help for the tasks that quietly eat up an owner’s week.",
    "pillars": [
      {
        "title": "Consultation and analysis",
        "text": "Sit down with us to review your numbers, spot leaks and decide what to fix first, with a clear written summary afterward."
      },
      {
        "title": "Collections follow-up",
        "text": "We keep track of what customers owe and what you owe suppliers, and follow up politely so cash keeps moving."
      },
      {
        "title": "Liaison and errands",
        "text": "We handle queues and paperwork, including PSA document requests and SSS or HDMF enrollments, so you can stay at your business."
      },
      {
        "title": "Property and notarial paperwork",
        "text": "We help prepare and coordinate documents for title transfers, deeds and notarization with the right professionals."
      }
    ],
    "included": [
      "Business consultation and financial analysis",
      "Accounts receivable and payable follow-up",
      "Liaison services and government requests",
      "SSS and HDMF enrollments",
      "Title transfer, deed and notarial assistance"
    ]
  },
  {
    "id": "it-consulting",
    "title": "Project Management / IT Consulting",
    "summary": "Plan it right. Deliver it on time.",
    "points": [
      "Technology assessment and roadmap",
      "Project plans, schedules and oversight",
      "Vendor and software selection",
      "Rollout, training and handover"
    ],
    "isNew": true,
    "lead": "Independent guidance for businesses that want technology to save time and money, with a project manager who keeps everything on schedule and within budget.",
    "pillars": [
      {
        "title": "Assess and plan",
        "text": "We study how your business runs today, find the manual or error-prone steps, and turn them into a ranked roadmap with costs and timelines."
      },
      {
        "title": "Manage the project",
        "text": "We act as your project lead: scope, schedule, budget, risks and weekly status updates, so vendors and teams stay aligned."
      },
      {
        "title": "Choose the right tools",
        "text": "We compare software and service providers against your needs and budget, then help you negotiate and decide with confidence."
      },
      {
        "title": "Roll out and support",
        "text": "We plan the switch-over, train your people, document the new process and stay on hand through the first weeks of use."
      }
    ],
    "included": [
      "Systems and process assessment",
      "Written technology roadmap",
      "Project planning, scheduling and oversight",
      "Vendor and software evaluation",
      "User training, documentation and handover"
    ],
    "steps": [
      {
        "title": "Discover",
        "text": "We interview your team and map current processes."
      },
      {
        "title": "Plan",
        "text": "You receive a roadmap, budget and timeline to approve."
      },
      {
        "title": "Deliver",
        "text": "We manage vendors and milestones with weekly updates."
      },
      {
        "title": "Hand over",
        "text": "Training, documents and a post-launch check-in."
      }
    ],
    "who": "Owners adopting accounting or inventory software, businesses moving from paper or spreadsheets to a system, and teams running a website or app project that needs a steady project lead."
  },
  {
    "id": "web-development",
    "title": "Website Design & Application Development",
    "summary": "Digital products built around your business.",
    "points": [
      "Websites and landing pages",
      "E-commerce solutions",
      "ERP and business management systems",
      "Mobile and web applications, digital tools and automation"
    ],
    "isNew": true,
    "lead": "We design and build the digital tools your business runs on: from a polished website to a custom system that ties sales, inventory and accounting together.",
    "pillars": [
      {
        "title": "Website",
        "text": "Fast, mobile-friendly, search-ready websites with your brand, services and contact details presented clearly, plus training so you can update content yourself."
      },
      {
        "title": "E-Commerce Solutions",
        "text": "Online stores with product catalogs, carts, local payment options and delivery set-up, connected to your inventory and sales records."
      },
      {
        "title": "ERP & Business Management Systems",
        "text": "One system for sales, purchasing, inventory, payroll and accounting, configured to the way your business works and to Philippine tax requirements."
      },
      {
        "title": "Mobile & Web Applications",
        "text": "Custom apps for customers, staff or partners, such as booking, ordering, tracking or dashboards, designed for everyday use on phones and desktops."
      },
      {
        "title": "Digital Tools & Automation",
        "text": "We connect your apps and remove repetitive work: automatic invoices and reminders, form-to-spreadsheet flows, reports and approvals."
      }
    ],
    "included": [
      "Website design and launch",
      "E-commerce store set-up",
      "ERP and business management system implementation",
      "Mobile and web application development",
      "Digital tools and workflow automation",
      "Hosting, security and ongoing support options"
    ],
    "steps": [
      {
        "title": "Discover",
        "text": "We learn your goals, users and must-have features."
      },
      {
        "title": "Design",
        "text": "You review layouts and flows before anything is built."
      },
      {
        "title": "Build",
        "text": "We develop in stages with demos along the way."
      },
      {
        "title": "Launch & support",
        "text": "Go-live, training and monthly care plans."
      }
    ],
    "who": "Businesses that need a first website, shops selling online, and growing companies outgrowing spreadsheets and ready for a connected system."
  }
]

export const INDUSTRIES: [string, string, string][] = [["Food & Retail","Restaurants, cafés, sari-sari stores, and retail shops.","Whether it's one cozy café or a multi-branch chain, we help you plan, price, and systemize daily sales and inventory so you can focus on your customers."],
["Manufacturing","For makers, factories, and producers, big or small.","Operations planning, materials tracking, and ERP systems built for the way Philippine manufacturers actually work."],
["E-commerce & Online Sellers","Shopee, Lazada, TikTok Shop, Shopify, we know the drill.","From registration to your own online store, we help you manage channels, marketing, and the numbers behind every order."],
["Professional Services","Consultants, agencies, freelancers, and creators.","Registration, pricing, clean billing, and growth planning, so you can focus on great work."],
["Real Estate","Brokers, developers, and lessors.","Permits, documentation, sales support, and project tracking for property businesses."],
["Motor Vehicle Leasing","Fleet operators and vehicle lessors.","Operations systems, permit guidance, and fleet tracking tools so you know which units earn their keep."],
["Architecture & Design Studios","Architects, interior designers, and creative studios.","Project-based fees, milestone billing, and client management, organized so you stay at the drafting table."],
["General Construction","Contractors and builders, residential to commercial.","Project planning, permits, and progress tracking built for the site."],
["Engineering Consultancy","Engineering firms and technical consultants.","Retainer and project management, documentation, and systems for multi-stage deliverables."],
["Property Management","Condo corporations, admins, and building managers.","Collections, records, and reporting that show owners and boards where the money goes."],
["Clinics & Pharmacy","Medical clinics, dental offices, and drugstores.","Permits, patient and inventory systems, and records kept clean and audit-ready."],
["Freight Forwarding","Cargo, customs brokerage, and forwarding firms.","Shipment tracking, documentation workflows, and clear margins per job."],
["Franchising Business","Franchisors and multi-branch franchisees.","Standard operating systems and consolidated reporting so the brand scales cleanly."],
["Arts & Film Production","Production houses, studios, and creative teams.","Project budgets, talent and vendor management, and production documentation."],
["Beauty & Wellness","Salons, spas, clinics, and wellness brands.","Booking, sales and inventory systems, and marketing that keeps clients coming back."],
["Fintech","Payments, lending, and financial technology firms.","Licensing guidance, project management, and IT consulting as you scale."],
["Gaming & Gambling","Licensed gaming and amusement operators.","Business planning, documentation, and operations support within your regulatory framework."],
["Digital Marketing Services","Agencies, media buyers, and social media managers.","Client billing, project workflows, and tools that automate your reporting."],
["Transportation & Logistics","Trucking, delivery, and logistics operators.","Route and fleet systems, per-trip margins, and operations planning."],
["Rental & Leasing Services","Equipment, space, and asset lessors.","Asset tracking, lease records, and booking tools for steady rental income."]]
