import { useEffect, useRef } from 'react'
import { useAppData } from './lib/appdata'
import CookieNotice from './components/CookieNotice'
import Footer from './components/Footer'
import Header from './components/Header'
import MessengerButton from './components/MessengerButton'
import { useLinkInterceptor, useRoute } from './lib/router'
import { applyMeta, buildMeta } from './seo'
import AboutPage from './pages/AboutPage'
import BlogPage from './pages/Blog'
import Careers from './pages/Careers'
import ContactPage from './pages/ContactPage'
import Home from './pages/Home'
import Industries from './pages/Industries'
import LocationPage from './pages/LocationPage'
import Locations from './pages/Locations'
import NewsPage from './pages/News'
import NotFound from './pages/NotFound'
import Payment from './pages/Payment'
import PostPage from './pages/Post'
import Pricing from './pages/Pricing'
import ServiceDetail from './pages/ServiceDetail'
import ServicesPage from './pages/ServicesPage'

function Page({ path }: { path: string }) {
  const seg = path.split('/').filter(Boolean)
  if (path === '/') return <Home />
  if (path === '/services') return <ServicesPage />
  if (seg[0] === 'services' && seg.length === 2) return <ServiceDetail id={seg[1]} />
  if (path === '/industries') return <Industries />
  if (path === '/pricing') return <Pricing />
  if (path === '/news') return <NewsPage />
  if (path === '/about') return <AboutPage />
  if (path === '/careers') return <Careers />
  if (path === '/contact') return <ContactPage />
  if (path === '/payment') return <Payment />
  if (path === '/blog') return <BlogPage />
  if (seg[0] === 'blog' && seg.length === 2) return <PostPage slug={seg[1]} />
  if (path === '/locations') return <Locations />
  if (seg[0] === 'locations' && seg.length === 2) return <LocationPage region={seg[1]} />
  if (seg[0] === 'locations' && seg.length === 3) return <LocationPage region={seg[1]} area={seg[2]} />
  return <NotFound />
}

export default function App({ path: initial }: { path?: string }) {
  const path = useRoute(initial)
  const data = useAppData()
  const main = useRef<HTMLElement>(null)
  const first = useRef(true)
  useLinkInterceptor()
  useEffect(() => {
    applyMeta(buildMeta(path, data))
    if (first.current) { first.current = false; return }
    main.current?.focus({ preventScroll: true })
  }, [path, data])
  return (
    <>
      <a href="#main" onClick={(e) => { e.preventDefault(); main.current?.focus() }} className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2">Skip to content</a>
      <Header path={path} />
      <main id="main" ref={main} tabIndex={-1} className="outline-none"><Page path={path} /></main>
      <Footer />
      <MessengerButton />
      <CookieNotice />
    </>
  )
}
