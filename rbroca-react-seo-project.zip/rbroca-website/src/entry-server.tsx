import { renderToString } from 'react-dom/server'
import App from './App'
import { DataProvider, type AppData } from './lib/appdata'
import { buildMeta, headToString } from './seo'

export { routes } from './routes'

export function render(path: string, data: AppData) {
  const html = renderToString(<DataProvider value={data}><App path={path} /></DataProvider>)
  return { html, head: headToString(buildMeta(path, data), data.seo ?? {}) }
}
