import { STEPS } from '../data'
import { Reveal, SectionTitle } from './ui'

export default function Approach() {
  return (
    <section className="texture bg-navy-950 py-24 text-white md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <SectionTitle light eyebrow="How we work" title="A clear path from idea to results." />
        <ol className="mt-16 grid gap-10 md:grid-cols-4">
          {STEPS.map((s, i) => (
            <li key={s.title}>
              <Reveal delay={i * 120}>
                <div className="border-t-2 border-gold pt-6">
                  <span className="text-sm font-semibold tabular-nums text-gold">0{i + 1}</span>
                  <h3 className="mt-3 text-2xl font-extrabold">{s.title}</h3>
                  <p className="mt-3 leading-relaxed text-white/70">{s.text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
