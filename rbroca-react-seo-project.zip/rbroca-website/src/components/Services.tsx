import { url } from '../lib/router'
import { ArrowUpRight } from 'lucide-react'
import { SERVICES } from '../data'
import { Reveal, SectionTitle } from './ui'

export default function Services() {
  return (
    <section className="bg-paper py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-16 px-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <SectionTitle eyebrow="What we do" title={<>Six practices, <span className="text-navy-700">one team.</span></>} />
          <p className="mt-8 max-w-md text-lg leading-relaxed text-ink/70">From your first registration to your own business software, built for the realities of doing business in the Philippines.</p>
          <a href={url('/services')} className="btn btn-navy mt-8">See all services</a>
        </div>
        <ol className="divide-y divide-navy/15 border-y border-navy/15">
          {SERVICES.map((s, i) => (
            <li key={s.id}>
              <Reveal delay={i * 60}>
                <a href={url(`/services/${s.id}`)} className="group grid grid-cols-[3rem_1fr_auto] gap-x-4 py-9 transition hover:bg-white md:px-6">
                  <span className="pt-1 font-display text-sm font-extrabold tabular-nums text-navy-700/60">{String(i + 1).padStart(2, '0')}</span>
                  <span>
                    <span className="flex flex-wrap items-center gap-3"><span className="font-display text-2xl font-extrabold text-navy">{s.title}</span>{s.isNew && <span className="rounded-full bg-gold px-3 py-0.5 text-xs font-extrabold text-navy">NEW</span>}</span>
                    <span className="mt-2 block text-ink/70">{s.summary}</span>
                    <span className="mt-4 block space-y-1 text-[15px] text-ink/60">{s.points.map((p) => <span key={p} className="block before:mr-3 before:text-gold before:content-['—']">{p}</span>)}</span>
                  </span>
                  <ArrowUpRight className="mt-1 text-navy transition group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-gold" aria-hidden />
                </a>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
