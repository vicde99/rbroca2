import { Mail, MapPin, Phone, Send } from 'lucide-react'
import { SERVICES, SITE } from '../data'
import { useFormSubmit } from '../lib/useForm'
import { Field, Honeypot, StatusDialog } from './Form'
import { BrandIcon } from './Social'
import { Reveal } from './ui'

export function ContactForm({ initialService = '' }: { initialService?: string }) {
  const { sending, status, close, onSubmit } = useFormSubmit('Inquiry', { name: 'Name', business: 'Business', email: 'Email', phone: 'Phone', service: 'Service', message: 'Message' })
  return (
    <>
      <form onSubmit={(e) => void onSubmit(e)} className="relative rounded-3xl bg-white p-8 text-ink shadow-2xl md:p-10" aria-label="Contact form">
        <Honeypot />
        <div className="grid gap-5 sm:grid-cols-2">
          <Field id="c-name" label="Your name *"><input id="c-name" name="name" required autoComplete="name" className="field" /></Field>
          <Field id="c-biz" label="Business name"><input id="c-biz" name="business" autoComplete="organization" className="field" /></Field>
          <Field id="c-email" label="Email *"><input id="c-email" name="email" type="email" required autoComplete="email" className="field" /></Field>
          <Field id="c-phone" label="Phone *"><input id="c-phone" name="phone" type="tel" required autoComplete="tel" className="field" /></Field>
        </div>
        <div className="mt-5"><Field id="c-service" label="Service of interest *">
          <select id="c-service" name="service" required defaultValue={initialService} className="field">
            <option value="" disabled>Choose a service</option><option>General inquiry</option>
            {SERVICES.map((s) => <option key={s.id}>{s.title}</option>)}
          </select></Field></div>
        <div className="mt-5"><Field id="c-msg" label="How can we help? *"><textarea id="c-msg" name="message" rows={4} required className="field" /></Field></div>
        <p className="mt-4 text-sm text-ink/60"><b>Please do not</b> include TINs, account numbers or other sensitive details. We use your details only to reply to this inquiry.</p>
        <button type="submit" disabled={sending} className="btn btn-navy mt-6 w-full disabled:opacity-60">{sending ? 'Sending…' : <>Send inquiry <Send size={18} /></>}</button>
      </form>
      <StatusDialog status={status} onClose={close} />
    </>
  )
}

export default function Contact({ level = 2 }: { level?: 1 | 2 }) {
  const H = (level === 1 ? 'h1' : 'h2') as 'h1'
  return (
    <section className="bg-navy-950 py-24 text-white md:py-32">
      <div className="mx-auto grid max-w-7xl gap-16 px-6 lg:grid-cols-2">
        <div>
          <p className="eyebrow">Contact</p>
          <H className="mt-4 text-4xl leading-tight md:text-5xl">Let’s talk about your business.</H>
          <span className="mt-6 block h-1 w-16 rounded bg-gold" aria-hidden />
          <p className="mt-8 max-w-md text-lg leading-relaxed text-white/75">Book a free 30-minute consultation. We will review your current setup and tell you what to fix first. We reply within one business day.</p>
          <ul className="mt-10 space-y-5 text-lg">
            <li className="flex items-center gap-4"><MapPin className="flex-none text-gold" aria-hidden />{SITE.address}</li>
            <li className="flex items-center gap-4"><Phone className="flex-none text-gold" aria-hidden /><a className="hover:text-gold" href={SITE.phoneHref}>{SITE.phone}</a></li>
            <li className="flex items-center gap-4"><Mail className="flex-none text-gold" aria-hidden /><a className="break-all hover:text-gold" href={`mailto:${SITE.email}`}>{SITE.email}</a></li>
            <li className="flex items-center gap-4"><span className="flex-none text-gold"><BrandIcon name="whatsapp" size={24} /></span><a className="hover:text-gold" href={`https://wa.me/${SITE.whatsapp}`} target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a></li>
          </ul>
        </div>
        <Reveal><ContactForm /></Reveal>
      </div>
    </section>
  )
}
