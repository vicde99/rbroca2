import { asset } from '../lib/asset'
import { Check } from 'lucide-react'
import { REGISTRATIONS } from '../data'
import { Reveal, SectionTitle } from './ui'

export default function About() {
  return (
    <section className="bg-white py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 lg:grid-cols-2">
          <SectionTitle eyebrow="Who we are" title="Financial clarity, delivered with a client-first approach." />
          <Reveal>
            <div className="relative mb-10 hidden lg:block"><div className="absolute -bottom-4 -right-4 h-full w-full rounded-3xl bg-gold" aria-hidden /><img src={asset('images/hero.jpg')} alt="RBRoca consultants meeting with clients" loading="lazy" className="relative h-64 w-full rounded-3xl object-cover object-[30%_40%]" /></div>
            <p className="text-xl leading-relaxed text-ink/75">
              RBRoca Business Consultancy is passionate about helping entrepreneurs and organizations achieve financial clarity and compliance. Combining technical expertise with a client-first approach, they deliver accounting and tax solutions that are accurate, responsive, and designed to support long-term business success.
            </p>
          </Reveal>
        </div>
        <ul className="mt-16 grid gap-6 md:grid-cols-2" aria-label="Registrations">
          {REGISTRATIONS.map((r) => (
            <li key={r.title} className="flex items-start gap-5 rounded-3xl border-2 border-gold bg-paper p-8">
              <span className="grid h-14 w-14 flex-none place-items-center rounded-full bg-gold text-navy-950"><Check size={28} strokeWidth={3} aria-hidden /></span>
              <div><h3 className="text-2xl text-navy">{r.title}</h3><p className="font-bold text-navy-700">{r.subtitle}</p><p className="mt-2 text-ink/70">{r.text}</p></div>
            </li>
          ))}
        </ul>
        <div className="mt-6 grid gap-6 md:grid-cols-2">
          <Reveal className="h-full">
            <article className="h-full rounded-3xl bg-navy-950 p-10 text-white">
              <h3 className="text-3xl font-extrabold text-gold">Mission</h3>
              <p className="mt-5 text-xl font-semibold leading-snug">Your reliable business partner prioritizing your compliance needs is here!</p>
              <p className="mt-4 leading-relaxed text-white/75">We provide expert accounting solutions at competitive prices, customized for various business types. Our objective is to establish enduring partnerships by offering reliable, cost-efficient services that cater to your specific requirements and promote sustainable success.</p>
            </article>
          </Reveal>
          <Reveal delay={120} className="h-full">
            <article className="h-full rounded-3xl bg-navy-950 p-10 text-white">
              <h3 className="text-3xl font-extrabold text-gold">Vision</h3>
              <p className="mt-5 leading-relaxed text-white/75">To become the trusted accounting firm for MSMEs and larger enterprises, offering scalable, reliable solutions that foster success at every stage of growth.</p>
            </article>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
