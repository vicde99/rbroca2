import { SITE } from '../data'

const paths = {
  facebook: <path fill="currentColor" d="M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.100 0 2.200.2 2.200.2v2.500h-1.300c-1.200 0-1.600.8-1.600 1.600V12h2.800l-.4 2.900h-2.300v7A10 10 0 0 0 22 12z" />,
  instagram: <g fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" fill="currentColor" /></g>,
  tiktok: <path fill="currentColor" d="M16.600 5.800a4.300 4.300 0 0 1-1-2.800h-3.100v12.400a2.600 2.600 0 1 1-2.600-2.600c.3 0 .5 0 .8.100V9.700a5.800 5.800 0 1 0 5 5.700V9.300a7.400 7.400 0 0 0 4.300 1.400V7.600a4.300 4.300 0 0 1-3.400-1.800z" />,
  whatsapp: <path fill="currentColor" d="M12 2a10 10 0 0 0-8.600 15.100L2 22l5-1.300A10 10 0 1 0 12 2zm0 1.900a8.100 8.100 0 1 1-4.100 15l-.3-.2-3 .8.8-2.900-.2-.3A8.100 8.100 0 0 1 12 3.900zM8.900 7.800c-.2 0-.5.1-.7.400-.3.300-1 1-1 2.400s1 2.700 1.100 2.900c.2.200 2 3.100 4.900 4.300 2.400.9 2.800.7 3.400.7.500-.1 1.700-.7 1.900-1.400.2-.7.200-1.200.2-1.400-.1-.1-.3-.2-.6-.4l-2-.9c-.3-.1-.5-.2-.7.200l-.9 1c-.1.200-.4.200-.7.100-.3-.1-1.300-.5-2.500-1.500-.9-.8-1.500-1.800-1.700-2.100-.2-.3 0-.5.100-.6l.5-.5c.1-.2.200-.3.300-.5s0-.4 0-.5l-.9-2.200c-.2-.5-.5-.5-.7-.5z" />,
}
export type Brand = keyof typeof paths

export function BrandIcon({ name, size = 20 }: { name: Brand; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>
}

const links: { name: Brand; label: string; href: string }[] = [
  { name: 'facebook', label: 'RBRoca on Facebook', href: SITE.facebook },
  { name: 'instagram', label: 'RBRoca on Instagram', href: SITE.instagram },
  { name: 'tiktok', label: 'RBRoca on TikTok', href: SITE.tiktok },
  { name: 'whatsapp', label: 'Chat with RBRoca on WhatsApp', href: `https://wa.me/${SITE.whatsapp}` },
]

export function SocialLinks() {
  return (
    <ul className="flex gap-3">
      {links.map((l) => (
        <li key={l.name}>
          <a href={l.href} target="_blank" rel="noopener noreferrer" aria-label={l.label}
            className="grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white transition hover:-translate-y-0.5 hover:bg-gold hover:text-navy">
            <BrandIcon name={l.name} />
          </a>
        </li>
      ))}
    </ul>
  )
}
