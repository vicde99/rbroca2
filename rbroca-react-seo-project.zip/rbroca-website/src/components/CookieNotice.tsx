import { useEffect, useState } from 'react'

const KEY = 'rbroca-notice'
export default function CookieNotice() {
  const [show, setShow] = useState(false)
  useEffect(() => { try { setShow(!localStorage.getItem(KEY)) } catch { setShow(true) } }, [])
  const done = () => { try { localStorage.setItem(KEY, '1') } catch { /* storage unavailable */ } setShow(false) }
  if (!show) return null
  return (
    <section aria-label="Cookie notice" className="fixed bottom-24 right-5 z-30 w-[calc(100%-2.5rem)] max-w-sm rounded-2xl border border-navy/10 bg-white p-5 text-ink shadow-2xl">
      <p className="font-display font-extrabold text-navy">We respect your privacy</p>
      <p className="mt-1 text-sm text-ink/70">This site uses only the browser storage it needs to work and does not use advertising or tracking cookies.</p>
      <button type="button" onClick={done} className="btn btn-navy mt-4 !px-5 !py-2.5">Got it</button>
    </section>
  )
}
