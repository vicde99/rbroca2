import { useEffect, useRef, type ReactNode } from 'react'
import { AlertCircle, CheckCircle2, X } from 'lucide-react'
import { SITE } from '../data'
import type { FormStatus } from '../lib/useForm'

export function Field({ id, label, children, hint }: { id: string; label: string; children: ReactNode; hint?: string }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-extrabold text-navy">{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-ink/60">{hint}</p>}
    </div>
  )
}

export function Honeypot() {
  return <div className="absolute -left-[9999px]" aria-hidden="true"><input name="website" tabIndex={-1} autoComplete="off" /></div>
}

export function StatusDialog({ status, onClose }: { status: FormStatus | null; onClose: () => void }) {
  const btn = useRef<HTMLButtonElement>(null)
  useEffect(() => {
    if (!status) return
    btn.current?.focus()
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', esc)
    return () => window.removeEventListener('keydown', esc)
  }, [status, onClose])
  if (!status) return null
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-navy-950/70 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="dlg-title" onClick={onClose}>
      <div className="w-full max-w-md rounded-3xl bg-white p-8 text-center text-ink shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className={`mx-auto grid h-16 w-16 place-items-center rounded-full text-white ${status.ok ? 'bg-emerald-600' : 'bg-red-600'}`}>{status.ok ? <CheckCircle2 size={34} /> : <AlertCircle size={34} />}</div>
        <h3 id="dlg-title" className="mt-5 text-2xl text-navy">{status.title}</h3>
        <p className="mt-3 text-ink/70">{status.message}</p>
        {status.mailto && <p className="mt-4 flex justify-center gap-5 font-bold underline"><a href={status.mailto}>Email us</a><a href={`https://wa.me/${SITE.whatsapp}`} target="_blank" rel="noopener noreferrer">WhatsApp</a></p>}
        <button ref={btn} type="button" onClick={onClose} className="btn btn-navy mt-6"><X size={16} aria-hidden /> Close</button>
      </div>
    </div>
  )
}
