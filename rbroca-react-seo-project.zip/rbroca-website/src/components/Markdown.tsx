import type { ReactNode } from 'react'
import { siteHref } from '../lib/links'

/** Small, safe Markdown subset: ## / ### headings, - and 1. lists, **bold**, [text](link). No raw HTML is ever rendered. */
function inline(text: string): ReactNode[] {
  const out: ReactNode[] = []
  const re = /(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g
  let last = 0
  let m: RegExpExecArray | null
  let k = 0
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index))
    const t = m[0]
    if (t.startsWith('**')) out.push(<strong key={k++}>{t.slice(2, -2)}</strong>)
    else {
      const mm = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(t)
      const href = mm ? siteHref(mm[2].trim()) : ''
      if (mm && href) out.push(<a key={k++} href={href} {...(href.startsWith('https://') ? { target: '_blank', rel: 'noopener noreferrer' } : {})} className="font-semibold text-navy underline decoration-gold decoration-2 underline-offset-4">{mm[1]}</a>)
      else if (mm) out.push(mm[1])
    }
    last = m.index + t.length
  }
  if (last < text.length) out.push(text.slice(last))
  return out
}

export default function Markdown({ source }: { source: string }) {
  const blocks = source.replace(/\r/g, '').split(/\n{2,}/).map((b) => b.trim()).filter(Boolean)
  return (
    <div className="space-y-5 text-lg leading-relaxed text-ink/85">
      {blocks.map((b, i) => {
        const lines = b.split('\n')
        if (/^###\s/.test(b)) return <h3 key={i} className="pt-4 text-xl text-navy">{inline(b.slice(4))}</h3>
        if (/^##\s/.test(b)) return <h2 key={i} className="pt-6 text-2xl text-navy">{inline(b.slice(3))}</h2>
        if (lines.every((l) => /^-\s/.test(l))) return <ul key={i} className="list-disc space-y-2 pl-6">{lines.map((l, j) => <li key={j}>{inline(l.slice(2))}</li>)}</ul>
        if (lines.every((l) => /^\d+\.\s/.test(l))) return <ol key={i} className="list-decimal space-y-2 pl-6">{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\d+\.\s/, ''))}</li>)}</ol>
        return <p key={i}>{inline(b.replace(/\n/g, ' '))}</p>
      })}
    </div>
  )
}
