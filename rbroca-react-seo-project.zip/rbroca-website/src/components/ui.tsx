import { url } from '../lib/router'
import { useEffect, useRef, useState, type ReactNode } from 'react'

const reduced = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

export function useInView<T extends Element>(threshold = 0.25) {
  const ref = useRef<T>(null)
  // Visible by default, so the server-rendered page and no-JS visitors always see the content.
  const [seen, setSeen] = useState(true)
  useEffect(() => {
    const el = ref.current
    if (!el || reduced() || !('IntersectionObserver' in window)) return
    if (el.getBoundingClientRect().top < window.innerHeight * 0.95) return
    setSeen(false)
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setSeen(true); io.disconnect() } }, { threshold })
    io.observe(el)
    return () => io.disconnect()
  }, [threshold])
  return [ref, seen] as const
}

export function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  const [ref, seen] = useInView<HTMLDivElement>(0.15)
  return (
    <div ref={ref} style={{ transitionDelay: `${delay}ms` }}
      className={`transition duration-700 ease-out motion-reduce:transition-none ${seen ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'} ${className}`}>
      {children}
    </div>
  )
}

export function CountUp({ to, prefix = '', suffix = '' }: { to: number; prefix?: string; suffix?: string }) {
  const [ref, seen] = useInView<HTMLSpanElement>(0.5)
  const [n, setN] = useState(to)
  useEffect(() => {
    if (!seen || reduced()) { setN(to); return }
    setN(1)
    const dur = Math.min(2600, 900 + to * 60), t0 = performance.now()
    let raf = 0
    const tick = (now: number) => {
      const p = Math.min((now - t0) / dur, 1)
      setN(Math.max(1, Math.round(1 + (to - 1) * (1 - Math.pow(1 - p, 3)))))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [seen, to])
  return <span ref={ref} aria-label={`${prefix}${to}${suffix}`} role="img">{prefix}{n}{suffix}</span>
}

export function SectionTitle({ eyebrow, title, light = false }: { eyebrow: string; title: ReactNode; light?: boolean }) {
  return (
    <div className="max-w-2xl">
      <p className={`eyebrow ${light ? '' : '!text-navy-700'}`}>{eyebrow}</p>
      <h2 className={`mt-4 text-4xl font-semibold leading-[1.1] tracking-tight md:text-5xl ${light ? 'text-white' : 'text-navy'}`}>{title}</h2>
      <span className="mt-6 block h-1 w-16 rounded bg-gold" aria-hidden />
    </div>
  )
}

/** Curved section transition. Set the colour with a text-* class (the colour of the NEXT section). */
export function Wave({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 1440 80" preserveAspectRatio="none" className={`pointer-events-none block h-10 w-full md:h-16 ${className}`} aria-hidden="true">
      <path fill="currentColor" d="M0 80V44C220 6 470 4 720 34s500 34 720 8v38z" />
    </svg>
  )
}

export function PageHero({ eyebrow, title, children }: { eyebrow: string; title: ReactNode; children?: ReactNode }) {
  return (
    <section className="texture relative bg-navy-950 pt-36 text-white">
      <div className="mx-auto max-w-7xl px-6 pb-20">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-5 max-w-4xl text-4xl leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">{title}</h1>
        {children && <div className="mt-6 max-w-2xl text-lg leading-relaxed text-white/75">{children}</div>}
      </div>
      <Wave className="text-paper" />
    </section>
  )
}

export function CtaBand() {
  return (
    <section className="texture bg-navy-950 py-24 text-white">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-6 md:flex-row md:items-center">
        <div className="max-w-2xl"><h2 className="text-3xl leading-tight md:text-4xl">Ready to take the guesswork out of growth?</h2><p className="mt-4 text-white/75">Book a free 30-minute consultation. We will review your current setup and tell you what to fix first.</p></div>
        <a href={url('/contact')} className="btn btn-gold">Book a free consultation</a>
      </div>
    </section>
  )
}
