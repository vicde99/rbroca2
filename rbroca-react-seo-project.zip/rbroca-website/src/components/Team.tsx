import { TEAM } from '../data'
import { Reveal, SectionTitle } from './ui'

export default function Team() {
  return (
    <section className="bg-paper py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <SectionTitle eyebrow="Our team" title="Our team is our greatest asset." />
        <div className="mt-16 grid gap-10 md:grid-cols-3">
          {TEAM.map((m, i) => (
            <Reveal key={m.name} delay={i * 120}>
              <article>
                <div className="grid aspect-[4/5] place-items-center rounded-2xl bg-gradient-to-br from-navy-950 to-navy-700 text-7xl font-semibold text-gold" aria-hidden>{m.initials}</div>
                <h3 className="mt-6 text-2xl font-extrabold text-navy">{m.name}</h3>
                <p className="mt-1 text-sm font-semibold uppercase tracking-wider text-navy-700">{m.role}{m.cred ? ` · ${m.cred}` : ''}</p>
                {m.email && <a href={`mailto:${m.email}`} className="mt-3 block break-all font-bold text-navy underline hover:text-navy-700">{m.email}</a>}
                <p className="mt-4 leading-relaxed text-ink/70">{m.bio}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
