import { AREAS, REGIONS, areasOf, locationPath, regionPath } from '../locations'
import { useAppData } from '../lib/appdata'
import { url } from '../lib/router'
import { isAreaEnabled } from '../seo'
import { Reveal, SectionTitle } from './ui'

export default function ServiceAreas({ heading = true }: { heading?: boolean }) {
  const { seo } = useAppData()
  return (
    <section className="bg-white py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        {heading && <SectionTitle eyebrow="Where we serve" title="Based in Kawit, serving Cavite, Metro Manila, Bulacan and Rizal." />}
        <div className="mt-14 grid gap-10 md:grid-cols-2">
          {REGIONS.map((r, i) => (
            <Reveal key={r.id} delay={(i % 2) * 80}>
              <div className="border-t-2 border-gold pt-6">
                <h3 className="text-2xl text-navy"><a href={url(regionPath(r))} className="hover:text-navy-700">{r.label}</a></h3>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {areasOf(r.id).filter((a) => isAreaEnabled(seo, a.slug)).map((a) => <li key={a.slug}><a href={url(locationPath(a))} className="inline-block rounded-full border border-navy/20 px-4 py-1.5 text-sm font-semibold text-navy transition hover:border-gold hover:bg-gold/20">{a.name}</a></li>)}
                  {areasOf(r.id).length === 0 && <li className="text-ink/65">Province-wide coverage.</li>}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
        <p className="mt-10 text-sm text-ink/60">{AREAS.length}+ cities and districts served, and expanding.</p>
      </div>
    </section>
  )
}
