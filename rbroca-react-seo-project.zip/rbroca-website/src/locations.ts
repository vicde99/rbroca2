export type RegionId = 'cavite' | 'metro-manila' | 'bulacan' | 'rizal'
export interface Region { id: RegionId; name: string; iso: string; kind: 'province' | 'region'; label: string }
export interface Area { slug: string; name: string; region: RegionId; lgu: string; district?: string }

export const REGIONS: Region[] = [
  { id: 'cavite', name: 'Cavite', iso: 'PH-CAV', kind: 'province', label: 'Cavite' },
  { id: 'metro-manila', name: 'Metro Manila', iso: 'PH-00', kind: 'region', label: 'Metro Manila (NCR)' },
  { id: 'bulacan', name: 'Bulacan', iso: 'PH-BUL', kind: 'province', label: 'Bulacan' },
  { id: 'rizal', name: 'Rizal', iso: 'PH-RIZ', kind: 'province', label: 'Rizal' },
]

export const AREAS: Area[] = [
  { slug: 'kawit', name: 'Kawit', region: 'cavite', lgu: 'Municipality of Kawit' },
  { slug: 'imus', name: 'Imus', region: 'cavite', lgu: 'City of Imus' },
  { slug: 'general-trias', name: 'General Trias', region: 'cavite', lgu: 'City of General Trias' },
  { slug: 'bacoor', name: 'Bacoor', region: 'cavite', lgu: 'City of Bacoor' },
  { slug: 'rosario', name: 'Rosario', region: 'cavite', lgu: 'Municipality of Rosario' },
  { slug: 'tanza', name: 'Tanza', region: 'cavite', lgu: 'Municipality of Tanza' },
  { slug: 'magallanes', name: 'Magallanes', region: 'cavite', lgu: 'Municipality of Magallanes' },
  { slug: 'trece-martires', name: 'Trece Martires City', region: 'cavite', lgu: 'City of Trece Martires' },
  { slug: 'naic', name: 'Naic', region: 'cavite', lgu: 'Municipality of Naic' },
  { slug: 'intramuros', name: 'Intramuros', region: 'metro-manila', lgu: 'City of Manila', district: 'Manila' },
  { slug: 'tondo', name: 'Tondo', region: 'metro-manila', lgu: 'City of Manila', district: 'Manila' },
  { slug: 'santa-ana', name: 'Santa Ana', region: 'metro-manila', lgu: 'City of Manila', district: 'Manila' },
  { slug: 'santa-cruz', name: 'Santa Cruz', region: 'metro-manila', lgu: 'City of Manila', district: 'Manila' },
  { slug: 'sampaloc', name: 'Sampaloc', region: 'metro-manila', lgu: 'City of Manila', district: 'Manila' },
  { slug: 'paranaque', name: 'Parañaque', region: 'metro-manila', lgu: 'City of Parañaque' },
  { slug: 'pasig', name: 'Pasig', region: 'metro-manila', lgu: 'City of Pasig' },
  { slug: 'las-pinas', name: 'Las Piñas', region: 'metro-manila', lgu: 'City of Las Piñas' },
  { slug: 'mandaluyong', name: 'Mandaluyong', region: 'metro-manila', lgu: 'City of Mandaluyong' },
  { slug: 'pasay', name: 'Pasay', region: 'metro-manila', lgu: 'City of Pasay' },
  { slug: 'makati', name: 'Makati', region: 'metro-manila', lgu: 'City of Makati' },
  { slug: 'quezon-city', name: 'Quezon City', region: 'metro-manila', lgu: 'Quezon City' },
  { slug: 'antipolo', name: 'Antipolo', region: 'rizal', lgu: 'City of Antipolo' },
  { slug: 'taytay', name: 'Taytay', region: 'rizal', lgu: 'Municipality of Taytay' },
  { slug: 'cainta', name: 'Cainta', region: 'rizal', lgu: 'Municipality of Cainta' },
]

export const regionOf = (id: RegionId) => REGIONS.find((r) => r.id === id) as Region
export const areasOf = (id: RegionId) => AREAS.filter((a) => a.region === id)
export const findArea = (region: string, slug: string) => AREAS.find((a) => a.region === region && a.slug === slug)
export const findRegion = (id: string) => REGIONS.find((r) => r.id === id)
export const locationPath = (a: Area) => `/locations/${a.region}/${a.slug}`
export const regionPath = (r: Region) => `/locations/${r.id}`
