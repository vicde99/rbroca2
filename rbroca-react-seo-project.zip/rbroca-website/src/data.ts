export const SITE = {
  name: 'RBRoca',
  email: 'info@rbrocaconsultancy.com',
  phone: '+63 9617722601',
  phoneHref: 'tel:+639617722601',
  whatsapp: '639617722601',
  messenger: 'https://m.me/61580893335282',
  address: '1422 Tramo-Bantayan Kawit, Cavite, Philippines',
  facebook: 'https://www.facebook.com/profile.php?id=61580893335282',
  instagram: 'https://www.instagram.com/rbrocabusinessconsultancy',
  tiktok: 'https://www.tiktok.com/@rbrocaconsultancy',
}

export const NAV = [
  { label: 'Industries', href: '/industries' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'News', href: '/news' },
  { label: 'About', href: '/about' },
  { label: 'Careers', href: '/careers' },
  { label: 'Contact', href: '/contact' },
]

export { SERVICES } from './content'

export const STEPS = [
  { title: 'Listen', text: 'We learn your goals, challenges and where you are today.' },
  { title: 'Assess', text: 'We review operations, numbers and market to find real gaps.' },
  { title: 'Plan', text: 'You get a practical roadmap with priorities and timelines.' },
  { title: 'Support', text: 'We stay alongside you as the plan is put into action.' },
]

export const STATS = [
  { to: 25, suffix: '+', label: 'cities & districts served' },
  { to: 24, prefix: '<', suffix: 'h', label: 'reply time' },
  { to: 6, label: 'service lines' },
  { to: 3, label: 'management team' },
]

export interface Member { initials: string; name: string; role: string; cred: string; email?: string; bio: string }
export const TEAM: Member[] = [
  { initials: 'RR', name: 'Ricci Jan Mae B. Roca', role: 'Managing Director', cred: 'MBA, CTT', email: 'riccijanmae.roca@rbrocaconsultancy.com', bio: 'A trusted accounting and tax professional dedicated to helping businesses navigate financial and compliance requirements with confidence. With experience in accounting, taxation, payroll, and business documentation, she provides reliable, personalized support that allows clients to focus on growing their businesses.' },
  { initials: 'GM', name: 'Glyssa Mislang', role: 'Managing Director', cred: 'CPA', email: 'glyssa.mislang@rbrocaconsultancy.com', bio: 'A finance and tax professional with a strong background in corporate accounting, financial management, tax compliance, and academic leadership. Her experience spans group accounting, tax advisory, financial reporting, and professional education.' },
  { initials: 'LQ', name: 'Lime Quisias', role: 'Office Administration', cred: '', bio: 'A dedicated administrative professional with experience in client support, records management, and office operations. Her attention to detail and customer-focused approach deliver an efficient and professional experience for every client.' },
]


export const TIERS = [
  { name: 'Starter', sub: 'For new businesses and sole proprietors', best: 'DTI-registered businesses with up to 50 transactions a month, up to 3 employees, and non-VAT (percentage tax) filing.', items: ['Monthly bookkeeping (manual or cloud)', 'Monthly financial statements (P&L and balance sheet)', 'Quarterly percentage tax (2551Q)', 'Monthly 1601-C withholding (if you have employees)', 'Annual ITR (1701 / 1701A)', 'Annual 1604-C alphalist', 'One 30-minute review call each month'], no: ['VAT filings', 'Statutory audit', 'Payroll for 4+ employees'], cta: 'Get started' },
  { name: 'Growth', sub: 'For VAT-registered businesses', best: 'Corporations or sole proprietors above the ₱3M VAT threshold, 50–500 transactions a month, and 4–20 employees.', items: ['Everything in Starter, plus:', 'Monthly and quarterly VAT (2550M / 2550Q)', 'Expanded withholding (1601-EQ and 1604-E)', 'Quarterly income tax (1701Q / 1702Q)', 'Annual ITR (1701 / 1702-RT)', 'Semi-monthly payroll for up to 20 employees', 'SSS, PhilHealth and Pag-IBIG remittances', '13th month pay and year-end annualization', 'QuickBooks or Xero setup and upkeep', 'Two monthly review calls, with Slack / Viber access'], popular: true, cta: 'Get a tailored quote' },
  { name: 'Audit-Ready', sub: 'For corporations needing statutory audit', best: 'Corporations meeting SEC audit thresholds, 500+ transactions a month, multi-branch or multi-entity setups, and BOI / PEZA registrants.', items: ['Everything in Growth, plus:', 'Annual statutory financial audit', 'SEC AFS / GIS filing', 'GFFS preparation where required', 'Pre-audit health check four weeks before fieldwork', 'BIR audit (LOA) representation included', 'Annual internal controls review', 'Payroll for up to 80 employees', 'Consolidation for up to 3 entities', 'Dedicated partner-level review'], cta: 'Schedule a scoping call' },
]
export const ADDONS = ['Business registration (DTI / SEC + BIR + LGU)', 'BIR audit (LOA) representation', 'Books cleanup (per missed quarter)', 'QuickBooks / Xero implementation', '13th month computation only (one-off)', 'Project management / IT consulting', 'Website design and e-commerce solutions', 'ERP and business management systems', 'Mobile and web applications, digital tools and automation']
export const PRICING_FAQ: [string, string][] = [
  ['Is the price really fixed?', 'Yes. Each retainer is a flat monthly fee agreed in your proposal. We only revisit it if your scope changes, such as more employees or a new branch.'],
  ['What if I just need a one-off filing or consultation?', 'Your first 30-minute consultation is free, and one-off filings and add-on work are quoted per scope without a retainer.'],
  ['Do you charge setup fees?', 'Any onboarding or cleanup work is listed as a line item in your proposal before you sign, so there are no surprise charges.'],
  ['Can I switch tiers mid-year?', 'Yes. Move up or down when your business changes, and we adjust the monthly fee from the next billing cycle.'],
  ["What's not included in any tier?", 'Government fees and taxes, third-party software subscriptions, and work outside the agreed scope are billed separately.'],
]
export const REGISTRATIONS = [
  { title: 'BIR Form 2303', subtitle: 'Certificate of Registration', text: 'Registered with the Bureau of Internal Revenue.' },
  { title: 'DTI', subtitle: 'Business Name Registration', text: 'Registered with the Department of Trade and Industry.' },
]
