import { url } from '../lib/router'
import { useEffect } from 'react'
import Markdown from '../components/Markdown'
import { CtaBand, PageHero } from '../components/ui'
import { formatDate, useBlog } from '../lib/blog'

export default function PostPage({ slug }: { slug: string }) {
  const { blog, failed } = useBlog()
  const post = blog?.posts.find((p) => p.slug === slug)
  useEffect(() => { if (post) document.title = `${post.title} | RBRoca Business Consultancy` }, [post])
  if (!blog && !failed) return <PageHero eyebrow="Blog" title="Loading…" />
  if (!post) return <><PageHero eyebrow="Blog" title="Article not found.">This article may have been moved or removed.</PageHero><section className="bg-paper pb-24"><div className="mx-auto max-w-7xl px-6"><a href={url('/blog')} className="btn btn-navy">See all articles</a></div></section></>
  return (
    <>
      <PageHero eyebrow={post.tag ?? 'Blog'} title={post.title}>{[formatDate(post.date), post.author].filter(Boolean).join(' · ')}</PageHero>
      <article className="bg-paper pb-24 pt-8">
        <div className="mx-auto max-w-3xl px-6">
          {post.image?.startsWith('https://') && <img src={post.image} alt={post.title} className="mb-10 w-full rounded-3xl" />}
          <Markdown source={post.body} />
          <a href={url('/blog')} className="btn btn-navy mt-12">Back to blog</a>
        </div>
      </article>
      <CtaBand />
    </>
  )
}
