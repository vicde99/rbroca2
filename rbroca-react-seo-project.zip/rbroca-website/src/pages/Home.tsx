import Approach from '../components/Approach'
import Hero from '../components/Hero'
import ServiceAreas from '../components/ServiceAreas'
import Services from '../components/Services'
import Team from '../components/Team'
import { CtaBand, Wave } from '../components/ui'

export default function Home() {
  return (
    <>
      <Hero />
      <Services />
      <div className="bg-navy-950 text-paper"><Wave className="rotate-180 text-paper" /></div>
      <Approach />
      <div className="bg-paper text-navy-950"><Wave className="-mt-px text-navy-950" /></div>
      <Team />
      <ServiceAreas />
      <CtaBand />
    </>
  )
}
