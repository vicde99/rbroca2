import { ArrowUpRight } from 'lucide-react'
import { SERVICES, SITE } from '../data'
import { INDUSTRIES } from '../content'
import { useAppData } from '../lib/appdata'
import { url } from '../lib/router'
import { areasOf, findArea, findRegion, locationPath, regionPath } from '../locations'
import { isAreaEnabled, locationFaq } from '../seo'
import { CtaBand, PageHero, Reveal, SectionTitle } from '../components/ui'
import NotFound from './NotFound'

export default function LocationPage({ region, area }: { region: string; area?: string }) {
  const { seo } = useAppData()
  const r = findRegion(region)
  const a = area ? findArea(region, area) : undefined
  if (!r || (area && (!a || !isAreaEnabled(seo, a.slug)))) return <NotFound />
  const place = a ? a.name : r.name
  const where = a ? `${a.name}, ${r.name}` : r.label
  const note = seo.locations?.[a ? a.slug : r.id]?.note
  const nearby = areasOf(r.id).filter((x) => x.slug !== a?.slug && isAreaEnabled(seo, x.slug))
  const home = a?.slug === 'kawit'
  const faqs = locationFaq(place, r.name, a?.lgu)
  return (
    <>
      <PageHero eyebrow={a ? `${r.name} · Service area` : 'Service area'} title={`Accounting, tax and business support in ${place}.`}>
        {home ? `RBRoca is based right here in Kawit, Cavite. Visit us at ${SITE.address}.` : `Local guidance for businesses in ${where}, from our team based in Kawit, Cavite.`}
      </PageHero>
      <section className="bg-paper pb-20 pt-8">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-[3fr_2fr]">
          <div className="space-y-5 text-lg leading-relaxed text-ink/80">
            <p>RBRoca Business Consultancy helps owners and managers in {where} stay compliant and grow. We handle registration and permits, monthly bookkeeping and BIR filings, payroll, and we build the websites and business systems that save you time.</p>
            <p>{a ? `Whether you run a shop, a service business or a growing company in ${a.name}, ` : `Whether you run a shop, a service business or a growing company in ${place}, `}we scope our work to your size and budget. Your first 30-minute consultation is free.</p>
            {note && <p>{note}</p>}
            {home && <address className="rounded-2xl border border-navy/10 bg-white p-6 not-italic"><b className="text-navy">RBRoca Business Consultancy</b><br />{SITE.address}<br /><a className="font-bold underline" href={SITE.phoneHref}>{SITE.phone}</a><br /><a className="font-bold underline" href={`mailto:${SITE.email}`}>{SITE.email}</a></address>}
          </div>
          <div className="rounded-3xl bg-navy-950 p-8 text-white">
            <h2 className="text-2xl text-gold">Book a free consultation</h2>
            <p className="mt-3 text-white/75">Tell us about your business in {place} and we will recommend where to start.</p>
            <a href={url('/contact')} className="btn btn-gold mt-6 w-full">Talk to us</a>
          </div>
        </div>
      </section>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="What we do" title={`Our services for ${place}.`} />
          <ul className="mt-12 grid gap-x-12 md:grid-cols-2">
            {SERVICES.map((s, i) => (
              <li key={s.id}><Reveal delay={(i % 2) * 60}><a href={url(`/services/${s.id}`)} className="group flex items-start justify-between gap-4 border-t border-navy/15 py-6"><span><span className="font-display text-xl font-extrabold text-navy">{s.title}</span><span className="mt-1 block text-ink/65">{s.summary}</span></span><ArrowUpRight className="mt-1 flex-none text-navy transition group-hover:text-gold" aria-hidden /></a></Reveal></li>
            ))}
          </ul>
        </div>
      </section>
      <section className="bg-paper py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="Permits and registration" title={`Starting or renewing a business in ${place}.`} />
          <div className="mt-8 max-w-3xl space-y-4 text-lg leading-relaxed text-ink/80">
            <p>{a ? `Business permits in ${a.name} are processed through the ${a.lgu} Business Permits and Licensing Office (BPLO). ` : 'Business permits are processed through your city or municipal Business Permits and Licensing Office (BPLO). '}Most businesses also need DTI or SEC registration, a barangay clearance and BIR registration.</p>
            <p>We prepare the requirements, follow up the queues and keep a renewal calendar so your permits never lapse.</p>
          </div>
          <p className="mt-8 text-ink/70">Industries we support: {INDUSTRIES.slice(0, 8).map(([n], i) => <span key={n}>{i ? ', ' : ''}<a className="font-semibold text-navy underline decoration-gold decoration-2 underline-offset-4" href={url('/industries')}>{n}</a></span>)} and more.</p>
        </div>
      </section>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-3xl px-6">
          <h2 className="text-3xl text-navy">Questions from businesses in {place}</h2>
          <div className="mt-8 space-y-3">{faqs.map(([q, ans]) => <details key={q} className="rounded-2xl border border-navy/10 bg-paper p-5"><summary className="cursor-pointer font-display font-extrabold text-navy">{q}</summary><p className="mt-3 text-ink/70">{ans}</p></details>)}</div>
        </div>
      </section>
      <section className="bg-paper py-16">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="text-2xl text-navy">{a ? `Nearby areas we serve in ${r.name}` : `Areas we serve in ${r.name}`}</h2>
          <ul className="mt-5 flex flex-wrap gap-2">
            {nearby.map((x) => <li key={x.slug}><a href={url(locationPath(x))} className="inline-block rounded-full border border-navy/20 px-4 py-1.5 text-sm font-semibold text-navy hover:border-gold hover:bg-gold/20">{x.name}</a></li>)}
            {a && <li><a href={url(regionPath(r))} className="inline-block rounded-full bg-navy px-4 py-1.5 text-sm font-semibold text-white">All of {r.name}</a></li>}
            <li><a href={url('/locations')} className="inline-block rounded-full border border-navy/20 px-4 py-1.5 text-sm font-semibold text-navy hover:border-gold hover:bg-gold/20">All service areas</a></li>
          </ul>
        </div>
      </section>
      <CtaBand />
    </>
  )
}
