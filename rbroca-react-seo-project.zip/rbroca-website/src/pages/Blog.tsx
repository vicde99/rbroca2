import { url } from '../lib/router'
import { ArrowUpRight } from 'lucide-react'
import { CtaBand, PageHero, Reveal } from '../components/ui'
import { formatDate, useBlog } from '../lib/blog'

export default function BlogPage() {
  const { blog, failed } = useBlog()
  return (
    <>
      <PageHero eyebrow="Blog" title="Insights on business growth.">Practical articles on tax, compliance, operations and technology for Philippine businesses.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto max-w-7xl px-6">
          {failed && <p className="rounded-2xl border border-navy/10 bg-white p-6">Articles are not available right now. Please check back soon.</p>}
          {!blog && !failed && <p className="text-ink/60" role="status">Loading…</p>}
          {blog && blog.posts.length === 0 && <p className="text-ink/60">No articles yet. Please check back soon.</p>}
          {blog && (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {blog.posts.map((p, i) => (
                <Reveal key={p.slug} delay={(i % 3) * 80} className="h-full">
                  <a href={url(`/blog/${p.slug}`)} className="card-line group flex h-full flex-col p-8">
                    {p.tag && <span className="w-fit rounded-full bg-navy px-3 py-1 text-xs font-extrabold text-white">{p.tag}</span>}
                    {p.date && <p className="mt-3 text-sm text-ink/60">{formatDate(p.date)}</p>}
                    <h2 className="mt-3 text-2xl text-navy">{p.title}</h2>
                    <p className="mt-3 flex-1 leading-relaxed text-ink/70">{p.summary}</p>
                    <span className="mt-6 inline-flex items-center gap-1 font-display font-extrabold text-navy">Read article <ArrowUpRight size={18} className="transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden /></span>
                  </a>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
      <CtaBand />
    </>
  )
}
