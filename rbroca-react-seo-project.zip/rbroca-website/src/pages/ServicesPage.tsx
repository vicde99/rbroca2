import { url } from '../lib/router'
import { ArrowUpRight } from 'lucide-react'
import { SERVICES } from '../data'
import { CtaBand, PageHero, Reveal } from '../components/ui'

export default function ServicesPage() {
  return (
    <>
      <PageHero eyebrow="Our services" title="Six practices, one team.">From your first DTI or SEC registration to your own business software, built for the realities of doing business in the Philippines.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto grid max-w-7xl gap-6 px-6 md:grid-cols-2">
          {SERVICES.map((s, i) => (
            <Reveal key={s.id} delay={(i % 2) * 80} className="h-full">
              <a href={url(`/services/${s.id}`)} className="card-line group flex h-full flex-col p-8">
                <span className="flex items-center justify-between"><span className="font-display text-sm font-extrabold text-navy-700/60">{String(i + 1).padStart(2, '0')}</span>{s.isNew && <span className="rounded-full bg-gold px-3 py-0.5 text-xs font-extrabold text-navy">NEW</span>}</span>
                <h2 className="mt-4 text-2xl text-navy">{s.title}</h2>
                <p className="mt-2 font-semibold text-navy-700">{s.summary}</p>
                <ul className="mt-5 space-y-1.5 text-[15px] text-ink/65">{s.points.map((p) => <li key={p} className="before:mr-3 before:text-gold before:content-['—']">{p}</li>)}</ul>
                <span className="mt-6 inline-flex items-center gap-1 pt-2 font-display font-extrabold text-navy">Learn more <ArrowUpRight size={18} className="transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden /></span>
              </a>
            </Reveal>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  )
}
