import { useState } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { CtaBand, PageHero } from '../components/ui'
import { safeLink, useNews, type NewsItem } from '../lib/news'

const TABS = [{ id: 'tax', label: 'Tax reminders' }, { id: 'announcements', label: 'Announcements' }, { id: 'activities', label: 'Company activities' }] as const
type TabId = (typeof TABS)[number]['id']

function ItemCard({ item }: { item: NewsItem }) {
  const href = safeLink(item.link)
  const external = href.startsWith('https://')
  return (
    <article className="card-line flex h-full flex-col p-8">
      {item.tag && <span className="w-fit rounded-full bg-navy px-3 py-1 text-xs font-extrabold text-white">{item.tag}</span>}
      {item.date && <p className="mt-3 text-sm text-ink/60">{item.date}</p>}
      <h2 className="mt-4 text-2xl text-navy">{item.title}</h2>
      <p className="mt-3 flex-1 leading-relaxed text-ink/70">{item.summary}</p>
      {href && <a href={href} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})} className="mt-6 inline-flex items-center gap-1 font-display font-extrabold text-navy underline decoration-gold decoration-2 underline-offset-4 hover:text-navy-700">{item.linkLabel ?? 'Learn more'} <ArrowUpRight size={18} aria-hidden /></a>}
    </article>
  )
}

export default function NewsPage() {
  const { news, failed } = useNews()
  const [tab, setTab] = useState<TabId>('tax')
  const move = (e: React.KeyboardEvent, i: number) => {
    const k = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0
    if (!k) return
    e.preventDefault()
    const n = (i + k + TABS.length) % TABS.length
    setTab(TABS[n].id)
    document.getElementById(`tab-${TABS[n].id}`)?.focus()
  }
  return (
    <>
      <PageHero eyebrow="News" title="News & updates.">Tax reminders, company announcements and what we have been up to.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto max-w-7xl px-6">
          <div role="tablist" aria-label="News categories" className="flex flex-wrap gap-3">
            {TABS.map((t, i) => (
              <button key={t.id} id={`tab-${t.id}`} role="tab" type="button" aria-selected={tab === t.id} aria-controls={`panel-${t.id}`} tabIndex={tab === t.id ? 0 : -1}
                onClick={() => setTab(t.id)} onKeyDown={(e) => move(e, i)}
                className={`rounded-full border-2 border-navy px-6 py-2.5 font-display font-extrabold transition ${tab === t.id ? 'bg-navy text-white' : 'text-navy hover:bg-navy/5'}`}>{t.label}</button>
            ))}
          </div>

          {failed && <p className="mt-10 rounded-2xl border border-navy/10 bg-white p-6">News is not available right now. You can still view the <a className="font-bold underline" href="https://www.bir.gov.ph/Tax-Reminder" target="_blank" rel="noopener noreferrer">official BIR Tax Reminder</a>.</p>}
          {!news && !failed && <p className="mt-10 text-ink/60" role="status">Loading…</p>}

          {news && (
            <div className="mt-10">
              <div id="panel-tax" role="tabpanel" aria-labelledby="tab-tax" hidden={tab !== 'tax'}>
                <div className="rounded-3xl border-2 border-gold bg-white p-8 md:p-10">
                  <span className="rounded-full bg-navy px-3 py-1 text-xs font-extrabold text-white">{news.taxReminder.source}</span>
                  <h2 className="mt-4 text-3xl text-navy">{news.taxReminder.title}</h2>
                  <p className="mt-3 max-w-3xl leading-relaxed text-ink/70">{news.taxReminder.summary}</p>
                  {safeLink(news.taxReminder.link) && <a href={safeLink(news.taxReminder.link)} target="_blank" rel="noopener noreferrer" className="btn btn-navy mt-6">{news.taxReminder.linkLabel} <ArrowUpRight size={18} aria-hidden /></a>}
                </div>
                <h3 className="mt-12 text-2xl text-navy">Common deadlines</h3>
                <div className="mt-4 overflow-x-auto rounded-2xl border border-navy/10 bg-white">
                  <table className="w-full min-w-[34rem] text-left">
                    <thead className="bg-navy text-white"><tr><th scope="col" className="px-5 py-3">Form</th><th scope="col" className="px-5 py-3">What it is</th><th scope="col" className="px-5 py-3">Usual deadline</th></tr></thead>
                    <tbody className="divide-y divide-navy/10">{news.taxReminder.reminders.map((r) => <tr key={r.form}><th scope="row" className="px-5 py-3 font-bold text-navy">{r.form}</th><td className="px-5 py-3">{r.what}</td><td className="px-5 py-3">{r.when}</td></tr>)}</tbody>
                  </table>
                </div>
                {news.taxReminder.note && <p className="mt-4 text-sm text-ink/60">{news.taxReminder.note}</p>}
              </div>
              <div id="panel-announcements" role="tabpanel" aria-labelledby="tab-announcements" hidden={tab !== 'announcements'} className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{news.announcements.map((i) => <ItemCard key={i.id} item={i} />)}</div>
              <div id="panel-activities" role="tabpanel" aria-labelledby="tab-activities" hidden={tab !== 'activities'} className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{news.activities.map((i) => <ItemCard key={i.id} item={i} />)}</div>
              {news.updated && <p className="mt-8 text-sm text-ink/60">Last updated: {news.updated}</p>}
            </div>
          )}
        </div>
      </section>
      <CtaBand />
    </>
  )
}
