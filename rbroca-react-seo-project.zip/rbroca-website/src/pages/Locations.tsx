import ServiceAreas from '../components/ServiceAreas'
import { CtaBand, PageHero } from '../components/ui'

export default function Locations() {
  return (
    <>
      <PageHero eyebrow="Service areas" title="Where we work.">RBRoca is based at 1422 Tramo-Bantayan, Kawit, Cavite, and supports businesses across Cavite, Metro Manila, Bulacan and Rizal.</PageHero>
      <ServiceAreas heading={false} />
      <CtaBand />
    </>
  )
}
