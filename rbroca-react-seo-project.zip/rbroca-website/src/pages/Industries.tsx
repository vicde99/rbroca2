import { url } from '../lib/router'
import { INDUSTRIES } from '../content'
import { CtaBand, PageHero, Reveal } from '../components/ui'

export default function Industries() {
  return (
    <>
      <PageHero eyebrow="Industries" title="Built for how you actually run.">Generic advice misses the daily Z-reading of retail, the costing of manufacturing, and the marketplace fees of e-commerce. We tailor our consulting and digital solutions to your industry.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <ul className="mx-auto grid max-w-7xl gap-x-12 px-6 md:grid-cols-2">
          {INDUSTRIES.map(([name, who, how], i) => (
            <li key={name}><Reveal delay={(i % 2) * 60}><div className="border-t border-navy/15 py-8"><h2 className="text-2xl text-navy">{name}</h2><p className="mt-2 font-semibold text-navy-700">{who}</p><p className="mt-2 leading-relaxed text-ink/65">{how}</p><a href={url('/contact')} className="mt-3 inline-block font-display font-extrabold text-navy underline decoration-gold decoration-2 underline-offset-4 hover:text-navy-700">Talk to us about {name.toLowerCase()}</a></div></Reveal></li>
          ))}
        </ul>
      </section>
      <CtaBand />
    </>
  )
}
