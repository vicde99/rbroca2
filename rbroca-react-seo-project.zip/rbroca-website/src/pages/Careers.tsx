import { Send, Upload } from 'lucide-react'
import { useFormSubmit } from '../lib/useForm'
import { Field, Honeypot, StatusDialog } from '../components/Form'
import { PageHero } from '../components/ui'

export default function Careers() {
  const { sending, status, close, onSubmit } = useFormSubmit('Job application', { name: 'Name', subject: 'Subject / Position', phone: 'Phone', email: 'Email', resume: 'Resume' })
  return (
    <>
      <PageHero eyebrow="Careers" title="Careers & internships.">We grow the next generation. Interns and OJTs are part of the team from day one, with hands-on work and real mentorship.</PageHero>
      <section className="bg-paper pb-24 pt-8">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl text-navy">Join RBRoca</h2>
            <p className="mt-4 text-lg leading-relaxed text-ink/70">Send us your details and resume. We are always interested in people who care about accuracy, service and growth, in consulting, finance, administration, marketing and technology.</p>
            <ul className="mt-8 space-y-4 text-ink/80">
              <li><b className="text-navy">Internships and OJT.</b> Hands-on projects with mentors.</li>
              <li><b className="text-navy">Growing team.</b> Cavite, Metro Manila, Bulacan and Rizal.</li>
              <li><b className="text-navy">Your privacy.</b> Applications are used only for hiring and kept up to 12 months.</li>
            </ul>
          </div>
          <form onSubmit={(e) => void onSubmit(e)} className="relative rounded-3xl bg-white p-8 shadow-xl md:p-10" aria-label="Job application form">
            <Honeypot />
            <div className="grid gap-5">
              <Field id="j-name" label="Full name *"><input id="j-name" name="name" required autoComplete="name" className="field" /></Field>
              <Field id="j-sub" label="Subject (position you are applying for) *"><input id="j-sub" name="subject" required className="field" /></Field>
              <Field id="j-phone" label="Contact number *"><input id="j-phone" name="phone" type="tel" required autoComplete="tel" className="field" /></Field>
              <Field id="j-email" label="Email *"><input id="j-email" name="email" type="email" required autoComplete="email" className="field" /></Field>
              <Field id="j-cv" label="Attach your resume *" hint="PDF, DOC or DOCX, up to 5 MB."><input id="j-cv" name="resume" type="file" accept=".pdf,.doc,.docx,application/pdf" required className="field file:mr-4 file:rounded-full file:border-0 file:bg-gold file:px-4 file:py-2 file:font-bold file:text-navy" /></Field>
            </div>
            <button type="submit" disabled={sending} className="btn btn-navy mt-6 w-full disabled:opacity-60">{sending ? 'Sending…' : <><Upload size={18} aria-hidden /> Submit application <Send size={18} aria-hidden /></>}</button>
          </form>
        </div>
        <StatusDialog status={status} onClose={close} />
      </section>
    </>
  )
}
