import About from '../components/About'
import Team from '../components/Team'
import { CtaBand, PageHero } from '../components/ui'

export default function AboutPage() {
  return (
    <>
      <PageHero eyebrow="About" title="Consulting that feels like a partnership.">Practical, personal, and built around your next step.</PageHero>
      <About />
      <Team />
      <CtaBand />
    </>
  )
}
