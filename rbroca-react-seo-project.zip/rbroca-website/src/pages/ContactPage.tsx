import Contact from '../components/Contact'

export default function ContactPage() {
  return <div className="pt-20"><Contact level={1} /></div>
}
