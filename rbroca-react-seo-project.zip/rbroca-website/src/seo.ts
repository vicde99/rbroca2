import { PRICING_FAQ, SERVICES, SITE } from './data'
import { asset } from './lib/asset'
import type { AppData } from './lib/appdata'
import { url } from './lib/router'
import { AREAS, REGIONS, findArea, findRegion, locationPath, regionOf, regionPath, type Area, type Region } from './locations'

export interface SeoSettings {
  siteUrl?: string
  business?: { name?: string; description?: string; phone?: string; email?: string; street?: string; locality?: string; region?: string; postalCode?: string; country?: string; lat?: number; lng?: number; sameAs?: string[] }
  defaults?: { titleSuffix?: string }
  pages?: Record<string, { title?: string; description?: string; noindex?: boolean }>
  locations?: Record<string, { note?: string; enabled?: boolean }>
  keywordLog?: { date: string; keyword: string; location?: string; engine?: string; position?: number | null; url?: string }[]
  checklist?: Record<string, boolean>
}

export interface Meta {
  title: string; description: string; path: string; canonical: string; robots: string; type: 'website' | 'article'
  geo: { region: string; placename: string }; jsonld: unknown[]
}

const BUSINESS = {
  name: 'RBRoca Business Consultancy',
  description: 'Accounting, tax, payroll, business documentation, IT consulting and web development for businesses in Cavite, Metro Manila, Bulacan and Rizal.',
  phone: SITE.phone, email: SITE.email, street: '1422 Tramo-Bantayan', locality: 'Kawit', region: 'Cavite', postalCode: '', country: 'PH',
  lat: 14.4333, lng: 120.9, sameAs: [SITE.facebook, SITE.instagram, SITE.tiktok],
}

export const clip = (s: string, n: number) => (s.length <= n ? s : `${s.slice(0, n - 1).replace(/\s+\S*$/, '')}…`)
export const originOf = (siteUrl?: string) => { try { return siteUrl ? new URL(siteUrl).origin : '' } catch { return '' } }
export const isAreaEnabled = (seo: SeoSettings, slug: string) => seo.locations?.[slug]?.enabled !== false

export const getBusiness = (seo: SeoSettings) => ({ ...BUSINESS, ...(seo.business ?? {}) })

/** Questions shown on location pages and in their FAQ structured data. */
export function locationFaq(place: string, regionName: string, lgu?: string): [string, string][] {
  return [
    [`Do you serve businesses in ${place}?`, `Yes. RBRoca supports businesses in ${place}, ${regionName} with bookkeeping and BIR filings, payroll, business registration and permits, IT consulting and website development. We are based in Kawit, Cavite.`],
    [`How do I get a business permit in ${place}?`, `${lgu ? `Business permits in ${place} are processed through the ${lgu} Business Permits and Licensing Office (BPLO). ` : `Business permits are processed through your city or municipal Business Permits and Licensing Office (BPLO). `}Most applicants also need DTI or SEC registration, a barangay clearance and BIR registration. We prepare the requirements and track your renewals.`],
    [`How much does it cost to work with RBRoca in ${place}?`, 'Your first 30-minute consultation is free. Monthly packages are fixed-fee and scoped to your business, and one-off work such as registration is quoted per scope, with no hidden costs.'],
  ]
}

const T = (t: string) => `${t} | RBRoca`

function business(seo: SeoSettings, origin: string) {
  const b = getBusiness(seo)
  const abs = (p: string) => (origin ? origin + p : p)
  return {
    '@context': 'https://schema.org', '@type': 'AccountingService', '@id': `${abs(url('/'))}#business`,
    name: b.name, description: b.description, url: abs(url('/')), logo: abs(asset('images/logo-mark.png')), image: abs(asset('images/hero.jpg')),
    telephone: b.phone, email: b.email,
    address: { '@type': 'PostalAddress', streetAddress: b.street, addressLocality: b.locality, addressRegion: b.region, ...(b.postalCode ? { postalCode: b.postalCode } : {}), addressCountry: b.country },
    geo: { '@type': 'GeoCoordinates', latitude: b.lat, longitude: b.lng },
    areaServed: [
      ...REGIONS.map((r) => ({ '@type': 'AdministrativeArea', name: r.name })),
      ...AREAS.filter((a) => isAreaEnabled(seo, a.slug)).map((a) => ({ '@type': 'City', name: a.name, containedInPlace: { '@type': 'AdministrativeArea', name: regionOf(a.region).name } })),
    ],
    sameAs: b.sameAs,
    knowsAbout: ['Bookkeeping', 'Philippine tax compliance', 'Payroll', 'Business registration', 'IT consulting', 'Web development'],
    hasOfferCatalog: { '@type': 'OfferCatalog', name: 'RBRoca services', itemListElement: SERVICES.map((s) => ({ '@type': 'Offer', itemOffered: { '@type': 'Service', name: s.title, description: s.summary } })) },
  }
}
const crumbs = (origin: string, items: [string, string][]) => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map(([name, p], i) => ({ '@type': 'ListItem', position: i + 1, name, item: (origin ? origin : '') + url(p) })) })
const faq = (qa: [string, string][]) => ({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: qa.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) })

export function buildMeta(path: string, data: AppData): Meta {
  const seo = data.seo ?? {}
  const origin = originOf(seo.siteUrl)
  const abs = (p: string) => (origin ? origin + p : p)
  const biz = business(seo, origin)
  const home: [string, string] = ['Home', '/']
  let m: Omit<Meta, 'path' | 'canonical'> = { title: 'Page not found | RBRoca', description: 'This page could not be found.', robots: 'noindex, follow', type: 'website', geo: { region: 'PH-CAV', placename: 'Kawit, Cavite' }, jsonld: [] }
  const geoHome = { region: 'PH-CAV', placename: 'Kawit, Cavite' }
  const page = (title: string, description: string, ld: unknown[] = [], extra: Partial<typeof m> = {}) => { m = { title, description: clip(description, 158), robots: 'index, follow, max-image-preview:large', type: 'website', geo: geoHome, jsonld: [biz, ...ld], ...extra } }
  const seg = path.split('/').filter(Boolean)

  if (path === '/') page('RBRoca | Accounting, Tax & Business Consultancy, Cavite', 'Accounting, tax, payroll, business permits, IT consulting and web development for businesses in Cavite, Metro Manila, Bulacan and Rizal. Book a free consultation.', [{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'RBRoca Business Consultancy', url: abs(url('/')), inLanguage: 'en-PH' }])
  else if (path === '/services') page(T('Accounting, Tax, HR and IT Services'), 'Six practices, one team: bookkeeping and tax, HR and payroll, business documentation, business support, IT consulting and web development for Philippine businesses.', [crumbs(origin, [home, ['Services', '/services']])])
  else if (seg[0] === 'services' && seg.length === 2 && SERVICES.some((s) => s.id === seg[1])) {
    const s = SERVICES.find((x) => x.id === seg[1])!
    page(T(`${s.title} in Cavite & Metro Manila`), `${s.lead} Serving Cavite, Metro Manila, Bulacan and Rizal.`, [crumbs(origin, [home, ['Services', '/services'], [s.title, path]]), { '@context': 'https://schema.org', '@type': 'Service', name: s.title, description: s.lead, serviceType: s.title, provider: { '@id': `${abs(url('/'))}#business` }, areaServed: REGIONS.map((r) => ({ '@type': 'AdministrativeArea', name: r.name })) }])
  } else if (path === '/industries') page(T('Industries We Serve'), 'Accounting, compliance and digital systems tailored to retail, manufacturing, e-commerce, professional services, real estate, construction, clinics and more.', [crumbs(origin, [home, ['Industries', '/industries']])])
  else if (path === '/pricing') page(T('Fixed-Fee Accounting Packages'), 'Transparent fixed-fee retainers for bookkeeping, tax, payroll and audit readiness. Choose Starter, Growth or Audit-Ready, or ask for a custom quote.', [crumbs(origin, [home, ['Pricing', '/pricing']]), faq(PRICING_FAQ)])
  else if (path === '/news') page(T('News, BIR Tax Reminders & Updates'), 'BIR tax reminders and common filing deadlines, company announcements and activities from RBRoca Business Consultancy.', [crumbs(origin, [home, ['News', '/news']])])
  else if (path === '/about') page(T('About Our Team'), 'Meet the RBRoca team: CPA and MBA professionals helping entrepreneurs achieve financial clarity and compliance. Registered with the BIR and DTI.', [crumbs(origin, [home, ['About', '/about']])])
  else if (path === '/careers') page(T('Careers & Internships'), 'Join RBRoca. Internships, OJT and career openings in consulting, finance, administration, marketing and technology in Cavite.', [crumbs(origin, [home, ['Careers', '/careers']])])
  else if (path === '/contact') page(T('Contact & Free Consultation'), 'Book a free 30-minute consultation. Visit 1422 Tramo-Bantayan, Kawit, Cavite, call +63 9617722601 or email info@rbrocaconsultancy.com.', [crumbs(origin, [home, ['Contact', '/contact']])])
  else if (path === '/payment') page(T('Payment: GCash, Maya and QR Ph'), 'Pay RBRoca with GCash, Maya or QR Ph and submit your payment details so we can match your payment.', [], { robots: 'noindex, follow' })
  else if (path === '/blog') page(T('Blog: Tax, Compliance & Business Tips'), 'Practical articles on tax, compliance, record keeping and business technology for Philippine businesses.', [crumbs(origin, [home, ['Blog', '/blog']])])
  else if (seg[0] === 'blog' && seg.length === 2) {
    const p = data.blog.posts.find((x) => x.slug === seg[1])
    if (p) page(T(p.title), p.summary, [crumbs(origin, [home, ['Blog', '/blog'], [p.title, path]]), { '@context': 'https://schema.org', '@type': 'BlogPosting', headline: p.title, description: p.summary, ...(p.date ? { datePublished: p.date, dateModified: data.blog.updated ?? p.date } : {}), author: { '@type': 'Organization', name: p.author ?? 'RBRoca Team' }, publisher: { '@id': `${abs(url('/'))}#business` }, mainEntityOfPage: abs(url(path)), inLanguage: 'en-PH' }], { type: 'article' })
  } else if (path === '/locations') page(T('Service Areas: Cavite, Metro Manila, Bulacan & Rizal'), 'RBRoca serves businesses in Kawit, Imus, Bacoor, Makati, Quezon City, Pasig, Antipolo, Bulacan and more across Cavite, Metro Manila, Bulacan and Rizal.', [crumbs(origin, [home, ['Service areas', '/locations']])])
  else if (seg[0] === 'locations' && seg.length === 2 && findRegion(seg[1])) {
    const r = findRegion(seg[1]) as Region
    page(T(`Accounting & Business Consultancy in ${r.name}`), `RBRoca helps businesses across ${r.name} with bookkeeping, BIR filings, payroll, permits, IT consulting and web development. Free 30-minute consultation.`, [crumbs(origin, [home, ['Service areas', '/locations'], [r.name, regionPath(r)]]), faq(locationFaq(r.name, r.label))], { geo: { region: r.iso, placename: r.name } })
  } else if (seg[0] === 'locations' && seg.length === 3 && findArea(seg[1], seg[2]) && isAreaEnabled(seo, seg[2])) {
    const a = findArea(seg[1], seg[2]) as Area; const r = regionOf(a.region)
    page(T(`Accounting, Tax & Business Support in ${a.name}`), `Bookkeeping, BIR filings, payroll, business permits, IT consulting and web development for businesses in ${a.name}, ${r.name}. Free 30-minute consultation.`,
      [crumbs(origin, [home, ['Service areas', '/locations'], [r.name, regionPath(r)], [a.name, locationPath(a)]]), faq(locationFaq(a.name, r.name, a.lgu)), { '@context': 'https://schema.org', '@type': 'Service', name: `Accounting, tax and business support in ${a.name}`, provider: { '@id': `${abs(url('/'))}#business` }, areaServed: { '@type': 'City', name: a.name, containedInPlace: { '@type': 'AdministrativeArea', name: r.name } } }],
      { geo: { region: r.iso, placename: `${a.name}, ${r.name}` } })
  }
  const o = seo.pages?.[path]
  const meta = { ...m, ...(o?.title ? { title: o.title } : {}), ...(o?.description ? { description: o.description } : {}), ...(o?.noindex ? { robots: 'noindex, follow' } : {}) }
  return { ...meta, path, canonical: origin && !meta.robots.startsWith('noindex') ? origin + url(path) : '' }
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')
export function headToString(meta: Meta, seo: SeoSettings): string {
  const b = getBusiness(seo); const origin = originOf(seo.siteUrl)
  const img = origin ? origin + asset('images/hero.jpg') : ''
  const t: string[] = [
    `<title>${esc(meta.title)}</title>`,
    `<meta name="description" content="${esc(meta.description)}" />`,
    `<meta name="robots" content="${esc(meta.robots)}" />`,
    meta.canonical ? `<link rel="canonical" href="${esc(meta.canonical)}" />` : '',
    meta.canonical ? `<link rel="alternate" hreflang="en-PH" href="${esc(meta.canonical)}" />` : '',
    `<meta property="og:type" content="${meta.type}" />`, `<meta property="og:site_name" content="${esc(b.name)}" />`, `<meta property="og:locale" content="en_PH" />`,
    `<meta property="og:title" content="${esc(meta.title)}" />`, `<meta property="og:description" content="${esc(meta.description)}" />`,
    meta.canonical ? `<meta property="og:url" content="${esc(meta.canonical)}" />` : '', img ? `<meta property="og:image" content="${esc(img)}" />` : '',
    `<meta name="twitter:card" content="summary_large_image" />`, `<meta name="twitter:title" content="${esc(meta.title)}" />`, `<meta name="twitter:description" content="${esc(meta.description)}" />`,
    `<meta name="geo.region" content="${meta.geo.region}" />`, `<meta name="geo.placename" content="${esc(meta.geo.placename)}" />`,
    `<meta name="geo.position" content="${b.lat};${b.lng}" />`, `<meta name="ICBM" content="${b.lat}, ${b.lng}" />`,
    ...meta.jsonld.map((j) => `<script type="application/ld+json">${JSON.stringify(j).replace(/</g, '\\u003c')}</script>`),
  ]
  return t.filter(Boolean).join('\n    ')
}

/** Updates the document head after client-side navigation. */
export function applyMeta(meta: Meta) {
  document.title = meta.title
  const set = (sel: string, attr: string, value: string, create: () => HTMLElement) => {
    let el = document.head.querySelector<HTMLElement>(sel)
    if (!value) { el?.remove(); return }
    if (!el) { el = create(); document.head.appendChild(el) }
    el.setAttribute(attr, value)
  }
  const metaTag = (key: 'name' | 'property', v: string) => () => { const e = document.createElement('meta'); e.setAttribute(key, v); return e }
  set('meta[name="description"]', 'content', meta.description, metaTag('name', 'description'))
  set('meta[name="robots"]', 'content', meta.robots, metaTag('name', 'robots'))
  set('meta[property="og:title"]', 'content', meta.title, metaTag('property', 'og:title'))
  set('meta[property="og:description"]', 'content', meta.description, metaTag('property', 'og:description'))
  set('meta[name="geo.region"]', 'content', meta.geo.region, metaTag('name', 'geo.region'))
  set('meta[name="geo.placename"]', 'content', meta.geo.placename, metaTag('name', 'geo.placename'))
  set('link[rel="canonical"]', 'href', meta.canonical, () => { const e = document.createElement('link'); e.setAttribute('rel', 'canonical'); return e })
  document.head.querySelectorAll('script[type="application/ld+json"]').forEach((s) => s.remove())
  meta.jsonld.forEach((j) => { const s = document.createElement('script'); s.type = 'application/ld+json'; s.text = JSON.stringify(j); document.head.appendChild(s) })
}

