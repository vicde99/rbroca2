import { StrictMode } from 'react'
import { createRoot, hydrateRoot } from 'react-dom/client'
import App from './App'
import { DataProvider, EMPTY, type AppData } from './lib/appdata'
import { asset } from './lib/asset'
import './index.css'

declare global { interface Window { __DATA__?: AppData } }

async function boot() {
  const root = document.getElementById('root') as HTMLElement
  let data = window.__DATA__
  const prerendered = Boolean(data)
  if (!data) {
    // Dev server: the data files are read at runtime. Production pages carry them inside the HTML.
    const get = (f: string) => fetch(asset(f)).then((r) => r.json()).catch(() => null)
    const [blog, news, seo] = await Promise.all([get('blog.json'), get('news.json'), get('seo.json')])
    data = { blog: blog ?? EMPTY.blog, news: news ?? EMPTY.news, seo: seo ?? {} }
  }
  const app = <StrictMode><DataProvider value={data}><App /></DataProvider></StrictMode>
  if (prerendered && root.hasChildNodes()) hydrateRoot(root, app)
  else createRoot(root).render(app)
}
void boot()
