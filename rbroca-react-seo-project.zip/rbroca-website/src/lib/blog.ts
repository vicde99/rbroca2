import { useAppData } from './appdata'

export interface Post { slug: string; title: string; date?: string; author?: string; tag?: string; summary: string; image?: string; body: string }
export interface Blog { updated?: string; posts: Post[] }

export const validSlug = (s: string) => /^[a-z0-9]+(-[a-z0-9]+)*$/.test(s)

export const formatDate = (d?: string) => {
  if (!d) return ''
  const x = new Date(`${d}T00:00:00`)
  return Number.isNaN(x.getTime()) ? d : x.toLocaleDateString('en-PH', { year: 'numeric', month: 'long', day: 'numeric' })
}

/** Articles are baked into every page at build time (and into the page itself for the browser). */
export function useBlog() {
  const { blog } = useAppData()
  return { blog: { ...blog, posts: (blog.posts ?? []).filter((p) => validSlug(p.slug) && p.title) }, failed: false }
}
