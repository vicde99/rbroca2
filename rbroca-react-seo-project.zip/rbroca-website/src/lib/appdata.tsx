import { createContext, useContext, type ReactNode } from 'react'
import type { Blog } from './blog'
import type { News } from './news'
import type { SeoSettings } from '../seo'

export interface AppData { blog: Blog; news: News; seo: SeoSettings }
export const EMPTY: AppData = { blog: { posts: [] }, news: { taxReminder: { title: '', source: '', link: '', linkLabel: '', summary: '', reminders: [] }, announcements: [], activities: [] }, seo: {} as SeoSettings }

const Ctx = createContext<AppData>(EMPTY)
export const DataProvider = ({ value, children }: { value: AppData; children: ReactNode }) => <Ctx.Provider value={value}>{children}</Ctx.Provider>
export const useAppData = () => useContext(Ctx)
