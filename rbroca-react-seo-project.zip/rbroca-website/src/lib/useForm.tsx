import { useState, type FormEvent } from 'react'
import { SITE } from '../data'

export interface FormStatus { ok: boolean; title: string; message: string; mailto?: string }

/** Sends a form to the business inbox through FormSubmit, with an honest fallback (email / WhatsApp links). */
export function useFormSubmit(kind: string, fields: Record<string, string>) {
  const [sending, setSending] = useState(false)
  const [status, setStatus] = useState<FormStatus | null>(null)

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const data = new FormData(form)
    if (data.get('website')) return
    const body = new FormData()
    const lines: string[] = []
    Object.entries(fields).forEach(([name, label]) => {
      const v = data.get(name)
      if (v instanceof File) { if (v.size) body.append('attachment', v); return }
      if (v !== null && String(v) !== '') { body.append(label, String(v)); lines.push(`${label}: ${String(v)}`) }
    })
    body.append('_replyto', String(data.get('email') ?? ''))
    body.append('_subject', `[RBRoca Website] ${kind} from ${String(data.get('name') ?? '')}`)
    body.append('_captcha', 'false')
    body.append('_template', 'table')
    setSending(true)
    try {
      const res = await fetch(`https://formsubmit.co/ajax/${SITE.email}`, { method: 'POST', body, headers: { Accept: 'application/json' } })
      const json: { success?: string | boolean; message?: string } = await res.json().catch(() => ({}))
      if (res.ok && (json.success === true || json.success === 'true')) {
        form.reset()
        setStatus({ ok: true, title: kind === 'Payment' ? 'Payment details sent' : 'Message sent', message: `Your details have been sent to our email (${SITE.email}). We will reply within one business day.` })
      } else if (/activat/i.test(json.message ?? '')) {
        setStatus({ ok: false, title: 'One-time activation needed', message: `We just emailed ${SITE.email} an activation link. Open it, click Activate, then send this form again.` })
      } else throw new Error('rejected')
    } catch {
      setStatus({ ok: false, title: 'Not sent', message: 'We could not send your details right now. Please email us or message us on WhatsApp.', mailto: `mailto:${SITE.email}?subject=${encodeURIComponent('RBRoca ' + kind)}&body=${encodeURIComponent(lines.join('\n'))}` })
    } finally { setSending(false) }
  }
  return { sending, status, close: () => setStatus(null), onSubmit }
}
