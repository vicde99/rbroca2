/** Resolves a file in /public so the site also works from a sub-folder (for example GitHub Pages). */
export const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`
