import { useAppData } from './appdata'
import { siteHref } from './links'

export interface Reminder { form: string; what: string; when: string }
export interface NewsItem { id: string; title: string; summary: string; tag?: string; date?: string; link?: string; linkLabel?: string }
export interface News {
  updated?: string
  taxReminder: { title: string; source: string; link: string; linkLabel: string; summary: string; note?: string; reminders: Reminder[] }
  announcements: NewsItem[]
  activities: NewsItem[]
}

/** Only https links and in-site hash links are rendered. */
export const safeLink = (u?: string) => siteHref(u)

export function useNews() {
  const { news } = useAppData()
  return { news: news.taxReminder.title ? news : null, failed: !news.taxReminder.title }
}
