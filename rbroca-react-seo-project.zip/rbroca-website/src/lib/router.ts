import { useEffect, useState } from 'react'

const rawBase = import.meta.env.BASE_URL ?? '/'
/** '' for a site at the domain root, or '/repo' for a GitHub project site. */
export const BASE = rawBase === '/' || rawBase === './' ? '' : rawBase.replace(/\/$/, '')

/** Real, crawlable URL for an app path: url('/services') -> '/services/' (with the base prefix). */
export const url = (p: string) => (p === '/' ? `${BASE}/` : `${BASE}${p.replace(/\/+$/, '')}/`)

const toPath = (pathname: string) => {
  let p = pathname
  if (BASE && p.startsWith(BASE)) p = p.slice(BASE.length)
  return p.replace(/\/+$/, '') || '/'
}

export function navigate(href: string) {
  window.history.pushState({}, '', href)
  window.dispatchEvent(new PopStateEvent('popstate'))
  window.scrollTo({ top: 0 })
}

export function useRoute(initial?: string) {
  const [path, setPath] = useState(() => initial ?? (typeof window !== 'undefined' ? toPath(window.location.pathname) : '/'))
  useEffect(() => {
    const on = () => setPath(toPath(window.location.pathname))
    window.addEventListener('popstate', on)
    return () => window.removeEventListener('popstate', on)
  }, [])
  return path
}

/** Single-page navigation for internal links, while every link stays a normal, crawlable <a href>. */
export function useLinkInterceptor() {
  useEffect(() => {
    const on = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return
      const a = (e.target as Element).closest('a')
      if (!a) return
      const href = a.getAttribute('href')
      if (!href || a.target || a.hasAttribute('download') || !href.startsWith('/')) return
      if (BASE && href !== BASE && !href.startsWith(`${BASE}/`)) return
      e.preventDefault()
      navigate(href)
    }
    document.addEventListener('click', on)
    return () => document.removeEventListener('click', on)
  }, [])
}
