import { url } from './router'

/** Only https links and in-site links are allowed. Links written for the HTML site (#contact, #svc-x, #post-x) map to this app's real URLs. */
const KNOWN = new Set(['services', 'industries', 'pricing', 'news', 'about', 'careers', 'contact', 'payment', 'blog', 'locations'])

export function siteHref(u?: string): string {
  if (!u) return ''
  if (u.startsWith('https://') || u.startsWith('mailto:')) return u
  if (u.startsWith('/')) return KNOWN.has(u.split('/')[1]) ? url(u) : ''
  if (!u.startsWith('#')) return ''
  if (u.startsWith('#/')) return siteHref(u.slice(1))
  if (u.startsWith('#svc-')) return url(`/services/${u.slice(5)}`)
  if (u.startsWith('#post-')) return url(`/blog/${u.slice(6)}`)
  return KNOWN.has(u.slice(1)) ? url(`/${u.slice(1)}`) : ''
}
