// Builds one static HTML file per page (so search engines and AI crawlers can read every page),
// plus sitemap.xml, robots.txt, llms.txt and 404.html. Runs after `vite build` and the SSR build.
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const root = process.cwd()
const dist = path.join(root, 'dist')
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(root, 'public', f), 'utf8')) } catch { return d } }
const seo = readJson('seo.json', {})
const blog = readJson('blog.json', { posts: [] })
const news = readJson('news.json', null)
const base = (process.env.VITE_BASE ?? '/').replace(/\/$/, '').replace(/^\.$/, '')
const siteUrl = (seo.siteUrl || process.env.SITE_URL || '').replace(/\/$/, '')
const data = { blog, news: news ?? { taxReminder: { title: '', source: '', link: '', linkLabel: '', summary: '', reminders: [] }, announcements: [], activities: [] }, seo: { ...seo, siteUrl } }

const entry = process.env.SSR_ENTRY ?? 'dist-ssr/entry-server.js'
const loaded = await import(pathToFileURL(path.join(root, entry)).href)
const mod = loaded.render ? loaded : loaded.default
const { render, routes } = mod

const template = fs.readFileSync(path.join(dist, 'index.html'), 'utf8')
  .replace(/<title>[\s\S]*?<\/title>\s*/, '')
  .replace(/<meta name="description"[^>]*>\s*/, '')
const dataJson = JSON.stringify(data).replace(/</g, '\\u003c')
const page = (html, head) => template.replace('<!--app-head-->', `${head}\n    <script>window.__DATA__=${dataJson}</script>`).replace('<!--app-html-->', html)
const write = (file, content) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, content) }

const list = routes(data)
for (const route of list) {
  const { html, head } = render(route, data)
  write(path.join(dist, route === '/' ? '' : route.slice(1), 'index.html'), page(html, head))
}
{ const { html, head } = render('/404-not-found', data); write(path.join(dist, '404.html'), page(html, head)) }

const url = (p) => `${base}${p === '/' ? '/' : p + '/'}`
const abs = (p) => (siteUrl ? new URL(siteUrl).origin + url(p) : url(p))
const today = new Date().toISOString().slice(0, 10)
const lastmod = (p) => { const post = p.startsWith('/blog/') && blog.posts.find((x) => x.slug === p.slice(6)); return (post && post.date) || (p === '/news' && news && news.updated) || (p === '/blog' && blog.updated) || today }
if (siteUrl) {
  const urls = list.filter((p) => p !== '/payment').map((p) => `  <url><loc>${abs(p)}</loc><lastmod>${lastmod(p)}</lastmod></url>`).join('\n')
  write(path.join(dist, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`)
} else console.warn('! No site URL set: sitemap.xml was not written. Set "siteUrl" in public/seo.json (CMS: SEO settings) or the SITE_URL variable.')
write(path.join(dist, 'robots.txt'), `User-agent: *\nAllow: /\n${siteUrl ? `\nSitemap: ${new URL(siteUrl).origin}${base}/sitemap.xml\n` : ''}`)

// llms.txt: a plain-language summary for AI assistants and answer engines (GEO).
const b = seo.business ?? {}
const names = (re) => list.filter((p) => re.test(p))
const sec = (title, paths, label) => `## ${title}\n${paths.map((p) => `- [${label(p)}](${abs(p)})`).join('\n')}\n`
const pretty = (p) => p.split('/').filter(Boolean).slice(-1)[0].replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
write(path.join(dist, 'llms.txt'), [
  `# ${b.name ?? 'RBRoca Business Consultancy'}`, '',
  `> ${b.description ?? ''}`, '',
  `Based at ${b.street ?? ''}, ${b.locality ?? ''}, ${b.region ?? ''}, Philippines. Phone ${b.phone ?? ''}. Email ${b.email ?? ''}. Serves Cavite, Metro Manila, Bulacan and Rizal. First 30-minute consultation is free.`, '',
  sec('Services', names(/^\/services\/.+/), pretty), sec('Service areas', names(/^\/locations\/[^/]+(\/[^/]+)?$/), pretty),
  sec('Key pages', ['/', '/pricing', '/industries', '/about', '/contact', '/news', '/blog'], (p) => (p === '/' ? 'Home' : pretty(p))),
  blog.posts.length ? sec('Articles', names(/^\/blog\/.+/), (p) => (blog.posts.find((x) => x.slug === p.slice(6)) || { title: pretty(p) }).title) : '',
].filter((x) => x !== '').join('\n') + '\n')
console.log(`Prerendered ${list.length} pages${siteUrl ? ' with sitemap.xml' : ''}.`)
