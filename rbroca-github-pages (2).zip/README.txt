RBRoca site for GitHub Pages
============================
Files
  index.html        the whole website
  news.json         News tab: BIR Tax Reminder card, announcements, company activities
  blog.json         Blog articles
  admin/index.html  Content Manager (CMS) for news, announcements and blog
  favicon.ico, favicon-32.png, apple-touch-icon.png   the RBRoca mark as the site icon
  .nojekyll         tells GitHub Pages to serve the files as they are

Publish on GitHub Pages
  1. Create a GitHub repository and upload everything in this zip to the main branch (keep the admin folder).
  2. Settings > Pages > Source: Deploy from a branch > Branch: main, folder: / (root) > Save.
  3. Your site appears at https://<user>.github.io/<repo>/ and the CMS at https://<user>.github.io/<repo>/admin/

CONTENT MANAGER (CMS)
=====================
Open  https://<your-site>/admin/  (add /admin/ to your site address).
It edits two files in your GitHub repository: news.json and blog.json.

First-time setup (about 3 minutes)
  1. On GitHub: Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token.
  2. Repository access: "Only select repositories" > choose this website's repository.
  3. Permissions > Repository permissions > Contents: Read and write. Generate and copy the token.
  4. Open /admin/, enter  owner/repository  (for example rbroca/rbroca-website), the branch (main),
     paste the token, and press "Connect and load content".

Everyday use
  - Announcements, Company activities: add, edit, reorder (arrows) or delete items. They show on the News page in this order.
  - Tax reminder: edit the BIR card text, link and the Common deadlines table.
  - Blog posts: New post, then fill in title, summary and article text (preview shown). The web address is created from the title.
    Article text: blank line between paragraphs, ## Heading, ### Subheading, - bullets, 1. numbered list, **bold**, [text](https://link).
  - Press "Save to GitHub". The site updates in about a minute. Nothing changes on the site until you press Save.

Good to know
  - The token stays in your browser and is sent only to GitHub. Leave "Remember" unchecked on shared computers.
  - Only people with write access to the repository (and a token) can publish changes. The admin page itself shows nothing without a token.
  - Offline option: "Open JSON files from my computer", edit, then "Download", and upload the files to your site yourself.
  - Links must start with https:// (or # for pages on this site). Cover images must be https:// addresses.

Notes
  - The contact, careers and payment forms send through FormSubmit to info@rbrocaconsultancy.com. The first submission sends a one-time activation email to that address.
  - If news.json or blog.json cannot be loaded, the site shows the copy built into index.html.
